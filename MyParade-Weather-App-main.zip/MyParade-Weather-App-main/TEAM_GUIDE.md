# Team Development Guide

## Project Structure Overview

This project is organized into **Frontend** and **Backend** sections to streamline team collaboration.

---

## 🎨 FRONTEND

All frontend code is located in the `client/` directory.

### Frontend Directory Structure

```
client/
├── index.html              # Main HTML entry point
├── src/
│   ├── App.tsx            # Main application component & routing
│   ├── main.tsx           # Application entry point
│   ├── index.css          # Global styles
│   │
│   ├── pages/             # Page components
│   │   ├── ClimatologyHome.tsx
│   │   ├── Home.tsx
│   │   └── not-found.tsx
│   │
│   ├── components/        # Reusable components
│   │   ├── ui/           # shadcn/ui components (Button, Card, etc.)
│   │   ├── Header.tsx
│   │   ├── MapPanel.tsx
│   │   ├── LocationPicker.tsx
│   │   ├── ClimatologyCard.tsx
│   │   ├── DatasetInfo.tsx
│   │   └── ... (other feature components)
│   │
│   ├── lib/              # Utilities & context
│   │   ├── climatologyData.ts   # Data utilities
│   │   ├── queryClient.ts       # TanStack Query setup
│   │   ├── tempContext.tsx      # React context
│   │   └── utils.ts             # Helper functions
│   │
│   └── hooks/            # Custom React hooks
│       ├── use-mobile.tsx
│       └── use-toast.ts
```

### Frontend Technologies
- **Framework**: React 18 + TypeScript
- **Routing**: Wouter
- **Styling**: Tailwind CSS + shadcn/ui
- **State Management**: React Context + TanStack Query
- **Maps**: MapLibre GL JS
- **Build Tool**: Vite

### Working on Frontend
- All UI components go in `client/src/components/`
- Page-level components go in `client/src/pages/`
- Use existing shadcn/ui components from `client/src/components/ui/`
- Global styles in `client/src/index.css`
- API calls use TanStack Query in `client/src/lib/queryClient.ts`

---

## ⚙️ BACKEND

All backend code is located in the `server/` directory.

### Backend Directory Structure

```
server/
├── index.ts      # Express server setup & entry point
├── routes.ts     # API route definitions
├── storage.ts    # Data storage interface & implementation
├── vite.ts       # Vite dev server configuration
├── data/         # Weather data files (Excel)
│   ├── orlando_aprils.xlsx
│   ├── tampa.xlsx
│   └── miami_celsius.xlsx
└── python/       # Python calculation scripts
    ├── weather_calculations.py  # Main calculation logic
    └── requirements.txt         # Python dependencies
```

### Backend Technologies
- **Runtime**: Node.js + TypeScript
- **Framework**: Express
- **ORM**: Drizzle (planned)
- **Database**: PostgreSQL (planned)
- **Current Storage**: In-memory
- **Data Processing**: Python (pandas, numpy) for weather calculations

### API Endpoints
- `POST /api/probabilities` - Climatology probability calculations
- `GET /api/history` - Historical weather observations
- `GET /api/trends` - Trend analysis data

### Working on Backend
- Add new routes in `server/routes.ts`
- Update storage interface in `server/storage.ts`
- Server entry point is `server/index.ts`
- API responses should match schemas in `shared/schema.ts`
- **Weather data files** go in `server/data/`
- **Python calculations** go in `server/python/`
  - Install Python dependencies: `pip install -r server/python/requirements.txt`
  - Main calculation module: `server/python/weather_calculations.py`

---

## 🔗 SHARED

Code shared between Frontend and Backend.

```
shared/
└── schema.ts     # Type definitions & Zod schemas
```

### Shared Technologies
- **Validation**: Zod
- **ORM Types**: Drizzle-Zod

### Working with Shared Code
- Define data models in `shared/schema.ts`
- Use Drizzle schemas for database tables
- Create Zod schemas for API validation
- Export TypeScript types for frontend/backend use

---

## 📋 Configuration Files (Root Level)

- `vite.config.ts` - Vite bundler configuration
- `tailwind.config.ts` - Tailwind CSS configuration
- `tsconfig.json` - TypeScript compiler options
- `package.json` - Dependencies & scripts
- `drizzle.config.ts` - Database ORM configuration
- `postcss.config.js` - PostCSS configuration

---

## 🚀 Development Workflow

### Starting the Application
```bash
npm run dev
```
This starts both the backend Express server and frontend Vite dev server on port 5000.

### Building for Production
```bash
npm run build
```

### Type Checking
```bash
npm run check
```

---

## 👥 Team Collaboration Tips

### Frontend Team
- Focus on files in `client/` directory
- Test UI changes at `http://localhost:5000`
- Component styling uses Tailwind classes
- Consult `shared/schema.ts` for data types

### Backend Team
- Focus on files in `server/` directory
- API endpoints accessible at `http://localhost:5000/api/*`
- Validate request bodies using schemas from `shared/schema.ts`
- Update storage interface for new data operations

### Full-Stack Features
1. **Define Schema** - Start in `shared/schema.ts`
2. **Build Backend** - Add routes in `server/routes.ts`
3. **Create Frontend** - Add components in `client/src/components/`
4. **Connect** - Use TanStack Query to call API endpoints

---

## 📝 Code Conventions

- **Frontend imports**: Use `@/` alias for client code, `@shared/` for shared code
- **Backend imports**: Use relative paths or `@shared/` for shared code
- **Components**: PascalCase (e.g., `MapPanel.tsx`)
- **Utilities**: camelCase (e.g., `climatologyData.ts`)
- **Types**: Export from `shared/schema.ts`

---

## 🔍 Quick Reference

| Task | Location |
|------|----------|
| Add new page | `client/src/pages/` |
| Create UI component | `client/src/components/` |
| Add API endpoint | `server/routes.ts` |
| Define data model | `shared/schema.ts` |
| Update storage logic | `server/storage.ts` |
| Add weather data file | `server/data/` |
| Add Python calculation | `server/python/` |
| Modify global styles | `client/src/index.css` |
| Add React hook | `client/src/hooks/` |
