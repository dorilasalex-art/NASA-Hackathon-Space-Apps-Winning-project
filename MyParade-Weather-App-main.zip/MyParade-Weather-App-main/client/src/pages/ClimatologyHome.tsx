import { useState, useEffect } from "react";
import Header from "@/components/Header";
import LocationPicker from "@/components/LocationPicker";
import MonthDayPicker from "@/components/MonthDayPicker";
import ClimatologyCard from "@/components/ClimatologyCard";
import ClimatologyCarousel from "@/components/ClimatologyCarousel";
import MapPanel from "@/components/MapPanel";
import DatasetInfo from "@/components/DatasetInfo";
import HistoryPanel from "@/components/HistoryPanel";
import PlannerTips from "@/components/PlannerTips";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { 
  fetchClimatologyData,
  type LocationData 
} from "@/lib/climatologyData";

export default function ClimatologyHome() {
  // Draft values (what user is editing)
  const [draftLocation, setDraftLocation] = useState({ lat: 28.06, lon: -82.41, name: "Tampa, FL" });
  const [draftTargetMonth, setDraftTargetMonth] = useState(4);
  const [draftTargetDay, setDraftTargetDay] = useState(15);
  const [draftTargetHour, setDraftTargetHour] = useState(12);
  const [draftWindowDays, setDraftWindowDays] = useState(7);
  
  // Applied values (what's being searched)
  const [location, setLocation] = useState({ lat: 28.06, lon: -82.41, name: "Tampa, FL" });
  const [targetMonth, setTargetMonth] = useState(4);
  const [targetDay, setTargetDay] = useState(15);
  const [targetHour, setTargetHour] = useState(12);
  const [windowDays, setWindowDays] = useState(7);
  
  const [currentLocationData, setCurrentLocationData] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = () => {
    // Apply draft values to trigger the search
    setLocation(draftLocation);
    setTargetMonth(draftTargetMonth);
    setTargetDay(draftTargetDay);
    setTargetHour(draftTargetHour);
    setWindowDays(draftWindowDays);
  };

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);
        setError(null);
        
        const data = await fetchClimatologyData(
          location.lat,
          location.lon,
          targetMonth,
          targetDay,
          targetHour
        );
        
        setCurrentLocationData(data);
        setLocation(prev => ({
          ...prev,
          name: data.name
        }));
        
      } catch (err) {
        console.error('Failed to fetch climatology data:', err);
        setError('Failed to fetch weather data from NASA. The data files may not be available for this date.');
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [location.lat, location.lon, targetMonth, targetDay, targetHour]);

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const targetDate = `${monthNames[targetMonth - 1]} ${targetDay}`;

  const currentClimatology = currentLocationData?.climatology || null;

  const climatologyCards = currentClimatology ? [
    currentClimatology.rain && (
      <ClimatologyCard
        key="rain"
        condition="rain"
        probability={currentClimatology.rain.probability}
        wilsonCI={currentClimatology.rain.wilsonCI}
        definition={currentClimatology.rain.definition}
        drivers={currentClimatology.rain.drivers}
      />
    ),
    currentClimatology.avgTemp && (
      <ClimatologyCard
        key="avgTemp"
        condition="avgTemp"
        probability={currentClimatology.avgTemp.probability}
        wilsonCI={currentClimatology.avgTemp.wilsonCI}
        definition={currentClimatology.avgTemp.definition}
        avgValue={currentClimatology.avgTemp.avgValue}
        drivers={currentClimatology.avgTemp.drivers}
      />
    ),
    currentClimatology.veryWindy && (
      <ClimatologyCard
        key="veryWindy"
        condition="veryWindy"
        probability={currentClimatology.veryWindy.probability}
        wilsonCI={currentClimatology.veryWindy.wilsonCI}
        definition={currentClimatology.veryWindy.definition}
        drivers={currentClimatology.veryWindy.drivers}
      />
    ),
    currentClimatology.heavyRain && (
      <ClimatologyCard
        key="heavyRain"
        condition="heavyRain"
        probability={currentClimatology.heavyRain.probability}
        wilsonCI={currentClimatology.heavyRain.wilsonCI}
        definition={currentClimatology.heavyRain.definition}
        drivers={currentClimatology.heavyRain.drivers}
      />
    ),
    currentClimatology.heatWave && (
      <ClimatologyCard
        key="heatWave"
        condition="heatWave"
        probability={currentClimatology.heatWave.probability}
        wilsonCI={currentClimatology.heatWave.wilsonCI}
        definition={currentClimatology.heatWave.definition}
        percentile={currentClimatology.heatWave.percentile}
        drivers={currentClimatology.heatWave.drivers}
      />
    ),
    currentClimatology.veryCold && (
      <ClimatologyCard
        key="veryCold"
        condition="veryCold"
        probability={currentClimatology.veryCold.probability}
        wilsonCI={currentClimatology.veryCold.wilsonCI}
        definition={currentClimatology.veryCold.definition}
        percentile={currentClimatology.veryCold.percentile}
        drivers={currentClimatology.veryCold.drivers}
      />
    ),
    currentClimatology.cloudCover && (
      <ClimatologyCard
        key="cloudCover"
        condition="cloudCover"
        probability={currentClimatology.cloudCover.probability}
        wilsonCI={currentClimatology.cloudCover.wilsonCI}
        definition={currentClimatology.cloudCover.definition}
        drivers={currentClimatology.cloudCover.drivers}
      />
    ),
    currentClimatology.snow && (
      <ClimatologyCard
        key="snow"
        condition="snow"
        probability={currentClimatology.snow.probability}
        wilsonCI={currentClimatology.snow.wilsonCI}
        definition={currentClimatology.snow.definition}
        drivers={currentClimatology.snow.drivers}
      />
    ),
    currentClimatology.uncomfortable && (
      <ClimatologyCard
        key="uncomfortable"
        condition="uncomfortable"
        probability={currentClimatology.uncomfortable.probability}
        wilsonCI={currentClimatology.uncomfortable.wilsonCI}
        definition={currentClimatology.uncomfortable.definition}
        drivers={currentClimatology.uncomfortable.drivers}
      />
    )
  ].filter(Boolean) : [];

  const mockProbabilities = currentClimatology ? {
    rain: currentClimatology.rain?.probability || null,
    heavyRain: currentClimatology.heavyRain?.probability || null,
    avgTemp: currentClimatology.avgTemp?.avgValue || currentClimatology.avgTemp?.probability || null,
    heatWave: currentClimatology.heatWave?.probability || null,
    veryCold: currentClimatology.veryCold?.probability || null,
    veryWindy: currentClimatology.veryWindy?.probability || null,
    cloudCover: currentClimatology.cloudCover?.probability || null,
    snow: currentClimatology.snow?.probability || null,
    uncomfortable: currentClimatology.uncomfortable?.probability || null
  } : {
    rain: null,
    heavyRain: null,
    avgTemp: null,
    heatWave: null,
    veryCold: null,
    veryWindy: null,
    cloudCover: null,
    snow: null,
    uncomfortable: null
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-96">
            <div className="text-center space-y-4">
              <div className="text-xl font-semibold">Loading climatology data...</div>
              <div className="text-sm text-muted-foreground">Fetching NASA satellite data for {location.name}</div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-96">
            <div className="text-center space-y-4">
              <div className="text-xl font-semibold text-destructive">Data Unavailable</div>
              <div className="text-sm text-muted-foreground max-w-md">
                {error}
              </div>
              <div className="text-xs text-muted-foreground mt-4">
                Note: NASA data files may not be available for all dates. The system is configured but waiting for correct data file paths.
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  // Check if we have any data
  const hasData = currentClimatology && Object.values(currentClimatology).some(v => v !== null);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Location Selection</CardTitle>
            </CardHeader>
            <CardContent>
              <LocationPicker 
                currentLocation={draftLocation}
                availableLocations={[
                  { name: "Tampa, FL", lat: 28.06, lon: -82.41 },
                  { name: "Orlando, FL", lat: 28.55, lon: -81.20 },
                  { name: "Miami, FL", lat: 25.76, lon: -80.38 }
                ]}
                onLocationChange={(lat, lon, name) => 
                  setDraftLocation({ lat, lon, name: name || `${lat}, ${lon}` })
                } 
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Target Period</CardTitle>
            </CardHeader>
            <CardContent>
              <MonthDayPicker 
                onDateChange={(month, day, hour, window) => {
                  setDraftTargetMonth(month);
                  setDraftTargetDay(day || 10);
                  setDraftTargetHour(hour || 12);
                  setDraftWindowDays(window || 7);
                }} 
              />
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-center">
          <Button 
            onClick={handleSearch} 
            size="lg"
            disabled={isLoading}
            className="min-w-[200px]"
            data-testid="button-search-climatology"
          >
            <Search className="mr-2 h-5 w-5" />
            {isLoading ? "Searching..." : "Search Climatology Data"}
          </Button>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Climatology Probabilities</h2>
          {!hasData ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-12 space-y-4">
                  <div className="text-lg font-medium text-muted-foreground">
                    No climatology data available
                  </div>
                  <div className="text-sm text-muted-foreground max-w-md mx-auto">
                    NASA satellite data is currently unavailable for this location and date. 
                    The API integration is working, but the specific data files are not accessible (404 errors).
                  </div>
                  <div className="text-xs text-muted-foreground">
                    This is a data availability issue, not a system error. Try different dates or wait for updated NASA file paths.
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <ClimatologyCarousel>
              {climatologyCards}
            </ClimatologyCarousel>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <MapPanel lat={location.lat} lon={location.lon} />
            {currentLocationData && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <HistoryPanel 
                  history={currentLocationData.historicalData} 
                  metric="rain" 
                  metricLabel="Rain Probability"
                  targetDate={targetDate}
                  windowDays={windowDays}
                />
                <HistoryPanel 
                  history={currentLocationData.historicalData} 
                  metric="temp" 
                  metricLabel="Temperature"
                  targetDate={targetDate}
                  windowDays={windowDays}
                />
              </div>
            )}
          </div>
          <div className="space-y-6">
            <PlannerTips probabilities={mockProbabilities} />
            <DatasetInfo 
              datasets={[
                {
                  name: "GLDAS",
                  version: "2.1",
                  source: "NASA GES DISC",
                  temporalResolution: "3-hourly",
                  spatialResolution: "0.25°",
                  coverage: "Last 10 years"
                },
                {
                  name: "GPM IMERG",
                  version: "07",
                  source: "NASA GES DISC",
                  temporalResolution: "30-minute",
                  spatialResolution: "0.1°",
                  coverage: "Last 10 years"
                },
                {
                  name: "MERRA-2",
                  version: "5.12.4",
                  source: "NASA GMAO",
                  temporalResolution: "Hourly",
                  spatialResolution: "0.5° × 0.625°",
                  coverage: "Last 10 years"
                }
              ]} 
              computedAt={new Date().toISOString()}
              cacheHit={false}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
