import { useState } from "react";
import Header from "@/components/Header";
import LocationPicker from "@/components/LocationPicker";
import TimeWindow from "@/components/TimeWindow";
import LikelihoodCard from "@/components/LikelihoodCard";
import MapPanel from "@/components/MapPanel";
import ExportReport from "@/components/ExportReport";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  const [location, setLocation] = useState({ lat: 28.5383, lon: -81.3792, name: "Tampa, FL" });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Location Selection</CardTitle>
            </CardHeader>
            <CardContent>
              <LocationPicker 
                onLocationChange={(lat, lon, name) => 
                  setLocation({ lat, lon, name: name || `${lat}, ${lon}` })
                } 
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Time Window & Resolution</CardTitle>
            </CardHeader>
            <CardContent>
              <TimeWindow 
                onTimeChange={(start, end, resolution) => 
                  console.log('Time configured:', { start, end, resolution })
                } 
              />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Condition Probabilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <LikelihoodCard
              condition="veryHot"
              probability={73}
              confidence={[61, 82]}
              drivers={{ "Tmax °C": 36.8, "RH %": 44 }}
              timeseries={[65, 68, 70, 73, 75, 73, 71]}
            />
            <LikelihoodCard
              condition="veryCold"
              probability={12}
              confidence={[8, 18]}
              drivers={{ "Tmin °C": 15.2, "Wind chill °C": 12.8 }}
              timeseries={[15, 14, 12, 11, 10, 12, 13]}
            />
            <LikelihoodCard
              condition="veryWindy"
              probability={45}
              confidence={[38, 52]}
              drivers={{ "Wind m/s": 8.5, "Gust m/s": 12.3 }}
              timeseries={[40, 42, 45, 48, 47, 45, 43]}
            />
            <LikelihoodCard
              condition="veryWet"
              probability={88}
              confidence={[82, 93]}
              drivers={{ "Precip mm": 12.5, "Rate mm/h": 3.2 }}
              timeseries={[75, 80, 85, 88, 90, 88, 85]}
            />
            <LikelihoodCard
              condition="veryUncomfortable"
              probability={61}
              confidence={[54, 68]}
              drivers={{ "Heat Index °C": 34.2, "RH %": 78 }}
              timeseries={[55, 58, 60, 61, 63, 62, 60]}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <MapPanel lat={location.lat} lon={location.lon} />
          </div>
          <div>
            <ExportReport />
          </div>
        </div>
      </main>
    </div>
  );
}
