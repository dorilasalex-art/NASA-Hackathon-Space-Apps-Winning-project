import { createContext, useContext, useState, ReactNode } from "react";

type TempUnit = "C" | "F";

interface TempContextType {
  unit: TempUnit;
  toggleUnit: () => void;
  convertTemp: (celsius: number) => number;
  getUnitSymbol: () => string;
}

const TempContext = createContext<TempContextType | undefined>(undefined);

export function TempProvider({ children }: { children: ReactNode }) {
  const [unit, setUnit] = useState<TempUnit>("C");

  const toggleUnit = () => {
    setUnit(prev => prev === "C" ? "F" : "C");
  };

  const convertTemp = (celsius: number): number => {
    if (unit === "F") {
      return (celsius * 9/5) + 32;
    }
    return celsius;
  };

  const getUnitSymbol = () => unit === "C" ? "°C" : "°F";

  return (
    <TempContext.Provider value={{ unit, toggleUnit, convertTemp, getUnitSymbol }}>
      {children}
    </TempContext.Provider>
  );
}

export function useTempUnit() {
  const context = useContext(TempContext);
  if (!context) {
    throw new Error("useTempUnit must be used within TempProvider");
  }
  return context;
}
