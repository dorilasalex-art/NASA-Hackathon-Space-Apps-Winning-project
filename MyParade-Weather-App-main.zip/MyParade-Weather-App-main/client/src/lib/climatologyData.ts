export interface ClimatologyCondition {
  probability: number | null;
  wilsonCI: [number, number] | null;
  definition: string;
  drivers: Record<string, number> | null;
  avgValue?: number | null;
  percentile?: number;
}

export interface HistoricalDataPoint {
  year: number;
  values: {
    rain: number;
    temp: number;
  };
}

export type ClimatologyMetrics = {
  rain: ClimatologyCondition | null;
  heavyRain: ClimatologyCondition | null;
  avgTemp: ClimatologyCondition | null;
  heatWave: ClimatologyCondition | null;
  veryCold: ClimatologyCondition | null;
  veryWindy: ClimatologyCondition | null;
  cloudCover: ClimatologyCondition | null;
  snow: ClimatologyCondition | null;
  uncomfortable: ClimatologyCondition | null;
};

export interface LocationData {
  name: string;
  coordinates: {
    lat: number;
    lon: number;
  };
  climatology?: ClimatologyMetrics;
  monthlyClimatology?: Record<string, ClimatologyMetrics>;
  historicalData: HistoricalDataPoint[];
}

export interface DatasetInfo {
  name: string;
  version: string;
  source: string;
  temporalResolution: string;
  spatialResolution: string;
  coverage: string;
}

export interface ClimatologyDataStructure {
  metadata: {
    dataVersion: string;
    computedAt: string;
    yearsRange: string;
    totalYears: number;
  };
  datasets: DatasetInfo[];
  locations: LocationData[];
}

export async function fetchClimatologyData(
  lat: number, 
  lon: number, 
  month: number, 
  day: number, 
  hour: number
): Promise<LocationData> {
  try {
    const response = await fetch('/api/fetch-weather', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        lat,
        lon,
        targetMonth: month,
        targetDay: day,
        targetHour: hour
      })
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.statusText}`);
    }

    const apiData = await response.json();
    
    // Transform API response to match frontend format
    return transformApiResponse(apiData, lat, lon);
  } catch (error) {
    console.error('Error fetching climatology data:', error);
    throw error;
  }
}

function transformApiResponse(apiData: any, lat: number, lon: number): LocationData {
  const temp = apiData.data?.temperature || {};
  const wind = apiData.data?.wind || {};
  const precip = apiData.data?.precipitation || {};
  
  // Extract statistics
  const tempStats = temp.statistics || {};
  const windStats = wind.statistics || {};
  const precipStats = precip.statistics || {};
  
  return {
    name: apiData.location || 'Unknown',
    coordinates: { lat, lon },
    climatology: {
      rain: precip.rain ? {
        probability: precip.rain.probability || null,
        wilsonCI: precip.rain.ci_lower && precip.rain.ci_upper 
          ? [precip.rain.ci_lower, precip.rain.ci_upper] 
          : null,
        definition: "≥1mm precipitation",
        drivers: precip.rain.count ? {
          "Historical days": precip.rain.count,
          "Total years": apiData.yearsAnalyzed || 0
        } : null
      } : null,
      
      heavyRain: precip.heavy_rain ? {
        probability: precip.heavy_rain.probability || null,
        wilsonCI: precip.heavy_rain.ci_lower && precip.heavy_rain.ci_upper 
          ? [precip.heavy_rain.ci_lower, precip.heavy_rain.ci_upper] 
          : null,
        definition: "≥P95 or ≥20mm/day",
        drivers: precip.heavy_rain.threshold ? {
          "P95 threshold": precip.heavy_rain.threshold
        } : null
      } : null,
      
      avgTemp: temp.avg_temp ? {
        probability: null,
        wilsonCI: null,
        definition: "Mean daily temperature",
        avgValue: temp.avg_temp.value || null,
        drivers: {
          "Mean": temp.avg_temp.value || 0,
          "Std Dev": temp.avg_temp.std || 0
        }
      } : null,
      
      heatWave: temp.heat_wave ? {
        probability: temp.heat_wave.probability || null,
        wilsonCI: temp.heat_wave.ci_lower && temp.heat_wave.ci_upper 
          ? [temp.heat_wave.ci_lower, temp.heat_wave.ci_upper] 
          : null,
        definition: "≥2 consecutive P90 days",
        percentile: 90,
        drivers: temp.heat_wave.threshold ? {
          "P90 threshold": temp.heat_wave.threshold
        } : null
      } : null,
      
      veryCold: temp.very_cold ? {
        probability: temp.very_cold.probability || null,
        wilsonCI: temp.very_cold.ci_lower && temp.very_cold.ci_upper 
          ? [temp.very_cold.ci_lower, temp.very_cold.ci_upper] 
          : null,
        definition: "P10 Tmin",
        percentile: 10,
        drivers: temp.very_cold.threshold ? {
          "P10 threshold": temp.very_cold.threshold
        } : null
      } : null,
      
      veryWindy: wind.very_windy ? {
        probability: wind.very_windy.probability || null,
        wilsonCI: wind.very_windy.ci_lower && wind.very_windy.ci_upper 
          ? [wind.very_windy.ci_lower, wind.very_windy.ci_upper] 
          : null,
        definition: "Wind ≥10 m/s",
        drivers: wind.very_windy.threshold ? {
          "Threshold": wind.very_windy.threshold
        } : null
      } : null,
      
      cloudCover: null, // Not yet implemented
      snow: null, // Not yet implemented
      uncomfortable: null // Not yet implemented
    },
    historicalData: [] // Will be populated later
  };
}

export function findLocationByName(
  data: ClimatologyDataStructure,
  locationName: string
): LocationData | undefined {
  return data.locations.find(
    loc => loc.name.toLowerCase() === locationName.toLowerCase()
  );
}

export function findClosestLocation(
  data: ClimatologyDataStructure,
  lat: number,
  lon: number
): LocationData {
  let closest = data.locations[0];
  let minDistance = Infinity;

  for (const location of data.locations) {
    const distance = Math.sqrt(
      Math.pow(location.coordinates.lat - lat, 2) +
      Math.pow(location.coordinates.lon - lon, 2)
    );
    
    if (distance < minDistance) {
      minDistance = distance;
      closest = location;
    }
  }

  return closest;
}

export function getAvailableLocations(data: ClimatologyDataStructure): Array<{
  name: string;
  lat: number;
  lon: number;
}> {
  return data.locations.map(loc => ({
    name: loc.name,
    lat: loc.coordinates.lat,
    lon: loc.coordinates.lon
  }));
}

export function getClimatologyForMonth(
  location: LocationData,
  month: number
): ClimatologyMetrics | null {
  if (location.monthlyClimatology) {
    const monthKey = month.toString();
    const monthSpecific = location.monthlyClimatology[monthKey];
    if (monthSpecific) {
      return monthSpecific;
    }
  }
  
  return location.climatology || null;
}
