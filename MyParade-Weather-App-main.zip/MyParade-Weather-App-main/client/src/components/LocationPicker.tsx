import { MapPin } from "lucide-react";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface LocationPickerProps {
  onLocationChange?: (lat: number, lon: number, name?: string) => void;
  currentLocation?: {
    lat: number;
    lon: number;
    name: string;
  };
  availableLocations?: Array<{
    name: string;
    lat: number;
    lon: number;
  }>;
}

const LOCATIONS = [
  { name: "Tampa, FL", lat: 28.06, lon: -82.41 },
  { name: "Orlando, FL", lat: 28.55, lon: -81.20 },
  { name: "Miami, FL", lat: 25.76, lon: -80.38 }
];

export default function LocationPicker({ 
  onLocationChange, 
  currentLocation
}: LocationPickerProps) {
  
  const handleLocationChange = (locationName: string) => {
    const location = LOCATIONS.find(loc => loc.name === locationName);
    if (location) {
      onLocationChange?.(location.lat, location.lon, location.name);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="location-select" className="text-sm font-medium mb-2 block">
          Select Location
        </Label>
        <Select 
          value={currentLocation?.name || "Tampa, FL"} 
          onValueChange={handleLocationChange}
        >
          <SelectTrigger id="location-select" data-testid="select-location">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <SelectValue placeholder="Select a location" />
            </div>
          </SelectTrigger>
          <SelectContent>
            {LOCATIONS.map((location) => (
              <SelectItem 
                key={location.name} 
                value={location.name}
                data-testid={`option-${location.name.toLowerCase().replace(/[, ]/g, '-')}`}
              >
                <div className="flex flex-col">
                  <span className="font-medium">{location.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {location.lat.toFixed(2)}°, {location.lon.toFixed(2)}°
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
