import { useState } from "react";
import { Calendar, Clock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TimeWindowProps {
  onTimeChange?: (start: string, end: string, resolution: string) => void;
}

export default function TimeWindow({ onTimeChange }: TimeWindowProps) {
  const now = new Date();
  const nowStr = now.toISOString().slice(0, 16);
  const next72h = new Date(now.getTime() + 72 * 60 * 60 * 1000).toISOString().slice(0, 16);

  const [startTime, setStartTime] = useState(nowStr);
  const [endTime, setEndTime] = useState(next72h);
  const [resolution, setResolution] = useState("hourly");

  const handleQuickSelect72h = () => {
    const newNow = new Date();
    const newNext72h = new Date(newNow.getTime() + 72 * 60 * 60 * 1000);
    setStartTime(newNow.toISOString().slice(0, 16));
    setEndTime(newNext72h.toISOString().slice(0, 16));
    console.log('Quick select: Now + Next 72h');
    onTimeChange?.(newNow.toISOString(), newNext72h.toISOString(), resolution);
  };

  const handleApply = () => {
    console.log('Time window applied:', { startTime, endTime, resolution });
    onTimeChange?.(startTime, endTime, resolution);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="start-time" className="text-sm font-medium mb-2 block">
            Start Date/Time
          </Label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              id="start-time"
              type="datetime-local"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              className="pl-9"
              data-testid="input-start-time"
            />
          </div>
        </div>
        <div>
          <Label htmlFor="end-time" className="text-sm font-medium mb-2 block">
            End Date/Time
          </Label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              id="end-time"
              type="datetime-local"
              value={endTime}
              onChange={(e) => setEndTime(e.target.value)}
              className="pl-9"
              data-testid="input-end-time"
            />
          </div>
        </div>
      </div>

      <div>
        <Label htmlFor="resolution" className="text-sm font-medium mb-2 block">
          Resolution
        </Label>
        <Select value={resolution} onValueChange={setResolution}>
          <SelectTrigger id="resolution" data-testid="select-resolution">
            <Clock className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="hourly">Hourly</SelectItem>
            <SelectItem value="3-hourly">3-Hourly</SelectItem>
            <SelectItem value="daily">Daily</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex gap-2">
        <Button 
          onClick={handleQuickSelect72h} 
          variant="outline" 
          className="flex-1"
          data-testid="button-quick-72h"
        >
          <Zap className="h-4 w-4 mr-2" />
          Now + Next 72h
        </Button>
        <Button onClick={handleApply} className="flex-1" data-testid="button-apply-time">
          Apply
        </Button>
      </div>
    </div>
  );
}
