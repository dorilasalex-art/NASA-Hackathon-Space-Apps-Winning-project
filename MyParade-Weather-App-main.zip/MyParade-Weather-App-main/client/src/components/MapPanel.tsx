import { useState, useRef, useEffect } from "react";
import Map, { Marker, NavigationControl } from 'react-map-gl/maplibre';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Map as MapIcon, Wind, CloudRain, Thermometer, MapPin } from "lucide-react";
import 'maplibre-gl/dist/maplibre-gl.css';

interface MapPanelProps {
  lat?: number;
  lon?: number;
}

export default function MapPanel({ lat = 28.5383, lon = -81.3792 }: MapPanelProps) {
  const [activeLayer, setActiveLayer] = useState<"wind" | "precip" | "temp">("temp");
  const mapRef = useRef<any>(null);

  const [viewState, setViewState] = useState({
    longitude: lon,
    latitude: lat,
    zoom: 8
  });

  useEffect(() => {
    if (mapRef.current) {
      mapRef.current.flyTo({
        center: [lon, lat],
        duration: 1000,
        essential: true
      });
    } else {
      setViewState(prev => ({
        ...prev,
        longitude: lon,
        latitude: lat
      }));
    }
  }, [lat, lon]);

  const layers = [
    { id: "temp" as const, icon: Thermometer, label: "Temperature" },
    { id: "wind" as const, icon: Wind, label: "Wind Speed" },
    { id: "precip" as const, icon: CloudRain, label: "Precipitation" },
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <MapIcon className="h-5 w-5" />
          Location Map
        </CardTitle>
        <div className="flex gap-1">
          {layers.map((layer) => (
            <Button
              key={layer.id}
              size="sm"
              variant={activeLayer === layer.id ? "default" : "outline"}
              onClick={() => {
                setActiveLayer(layer.id);
              }}
              data-testid={`button-layer-${layer.id}`}
            >
              <layer.icon className="h-3 w-3" />
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative rounded-lg overflow-hidden aspect-video border border-border">
          <Map
            ref={mapRef}
            {...viewState}
            onMove={(evt) => setViewState(evt.viewState)}
            mapStyle="https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json"
            style={{ width: '100%', height: '100%' }}
            longitude={lon}
            latitude={lat}
            data-testid="map-container"
          >
            <Marker
              longitude={lon}
              latitude={lat}
              anchor="bottom"
            >
              <div className="relative flex flex-col items-center">
                <MapPin className="h-8 w-8 text-primary fill-primary drop-shadow-lg" />
              </div>
            </Marker>
            
            <NavigationControl position="top-right" showCompass={false} />
          </Map>
        </div>

        <div className="flex items-center justify-between">
          <div className="text-sm">
            <span className="text-muted-foreground">Active Layer: </span>
            <span className="font-medium">{layers.find(l => l.id === activeLayer)?.label}</span>
          </div>
          <Badge variant="outline" data-testid="badge-coordinates">
            {lat.toFixed(4)}°, {lon.toFixed(4)}°
          </Badge>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="h-4 w-full bg-gradient-to-r from-blue-500 via-green-500 to-red-500 rounded" />
          <span className="whitespace-nowrap">0 - 100</span>
        </div>
      </CardContent>
    </Card>
  );
}
