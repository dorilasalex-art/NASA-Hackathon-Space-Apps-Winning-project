import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Thermometer, Snowflake, Wind, CloudRain, AlertTriangle } from "lucide-react";

interface LikelihoodCardProps {
  condition: "veryHot" | "veryCold" | "veryWindy" | "veryWet" | "veryUncomfortable";
  probability: number;
  confidence: [number, number];
  drivers: Record<string, number>;
  timeseries?: number[];
}

const conditionConfig = {
  veryHot: {
    title: "Very Hot",
    icon: Thermometer,
    gradient: "from-orange-500 to-red-500",
  },
  veryCold: {
    title: "Very Cold",
    icon: Snowflake,
    gradient: "from-cyan-500 to-blue-500",
  },
  veryWindy: {
    title: "Very Windy",
    icon: Wind,
    gradient: "from-teal-500 to-green-500",
  },
  veryWet: {
    title: "Very Wet",
    icon: CloudRain,
    gradient: "from-blue-400 to-indigo-500",
  },
  veryUncomfortable: {
    title: "Very Uncomfortable",
    icon: AlertTriangle,
    gradient: "from-purple-500 to-red-500",
  },
};

const getLabel = (p: number): string => {
  if (p <= 20) return "Low";
  if (p <= 40) return "Slight";
  if (p <= 60) return "Moderate";
  if (p <= 80) return "High";
  return "Very High";
};

export default function LikelihoodCard({
  condition,
  probability,
  confidence,
  drivers,
  timeseries = []
}: LikelihoodCardProps) {
  const config = conditionConfig[condition];
  const Icon = config.icon;
  const label = getLabel(probability);

  const driverText = Object.entries(drivers)
    .map(([key, value]) => `${key}: ${value.toFixed(1)}`)
    .join(", ");

  const max = Math.max(...timeseries, 1);
  const points = timeseries.map((val, i) => {
    const x = (i / (timeseries.length - 1)) * 100;
    const y = 100 - (val / max) * 100;
    return `${x},${y}`;
  }).join(" ");

  return (
    <Card className="hover-elevate" data-testid={`card-${condition}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Icon className="h-5 w-5" />
          {config.title}
        </CardTitle>
        <Badge variant="outline" className={`bg-gradient-to-r ${config.gradient} text-white border-0`}>
          {label}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <div className="text-5xl font-bold" data-testid={`text-probability-${condition}`}>
            {probability}%
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            90% CI: {confidence[0]}% - {confidence[1]}%
          </div>
        </div>

        {timeseries.length > 0 && (
          <svg viewBox="0 0 100 60" className="w-full h-15" preserveAspectRatio="none">
            <polyline
              fill="none"
              stroke="hsl(var(--primary))"
              strokeWidth="2"
              points={points}
            />
          </svg>
        )}

        <div className="pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground">
            Key drivers: {driverText}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
