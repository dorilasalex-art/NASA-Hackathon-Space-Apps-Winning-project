import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Umbrella, IceCream, MapPin, AlertTriangle } from "lucide-react";

interface Tip {
  icon: typeof Umbrella;
  text: string;
  priority: "high" | "medium" | "low";
}

interface PlannerTipsProps {
  probabilities: Record<string, number | null>;
}

export default function PlannerTips({ probabilities }: PlannerTipsProps) {
  const tips: Tip[] = [];

  if (probabilities.rain !== null && probabilities.rain > 60) {
    tips.push({
      icon: Umbrella,
      text: "Umbrella advisable - high rain probability",
      priority: "high"
    });
  }

  if (probabilities.heavyRain !== null && probabilities.heavyRain > 20) {
    tips.push({
      icon: AlertTriangle,
      text: "Consider backup indoor venue for heavy rain risk",
      priority: "high"
    });
  }

  if ((probabilities.avgTemp !== null && probabilities.avgTemp > 30) || (probabilities.heatWave !== null && probabilities.heatWave > 30)) {
    tips.push({
      icon: IceCream,
      text: "Plan for heat - provide shade and hydration",
      priority: "medium"
    });
  }

  if (probabilities.uncomfortable !== null && probabilities.uncomfortable > 50) {
    tips.push({
      icon: AlertTriangle,
      text: "Uncomfortable conditions likely - adjust schedule",
      priority: "medium"
    });
  }

  if (probabilities.veryWindy !== null && probabilities.veryWindy > 40) {
    tips.push({
      icon: MapPin,
      text: "Secure outdoor equipment - windy conditions expected",
      priority: "medium"
    });
  }

  const priorityColors = {
    high: "destructive",
    medium: "default",
    low: "secondary"
  } as const;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Lightbulb className="h-5 w-5" />
          Planning Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {tips.length > 0 ? (
          tips.map((tip, idx) => {
            const Icon = tip.icon;
            return (
              <div key={idx} className="flex items-start gap-3 p-3 rounded-lg border border-border hover-elevate">
                <Icon className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div className="flex-1 space-y-1">
                  <p className="text-sm">{tip.text}</p>
                  <Badge variant={priorityColors[tip.priority]} className="text-xs">
                    {tip.priority} priority
                  </Badge>
                </div>
              </div>
            );
          })
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">
            No specific recommendations for these conditions
          </p>
        )}
      </CardContent>
    </Card>
  );
}
