import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
import { useTempUnit } from "@/lib/tempContext";

interface HistoryEntry {
  year: number;
  values: Record<string, number>;
}

interface HistoryPanelProps {
  history: HistoryEntry[];
  metric: string;
  metricLabel: string;
  targetDate?: string;
  windowDays?: number;
}

export default function HistoryPanel({ 
  history, 
  metric, 
  metricLabel,
  targetDate,
  windowDays = 7
}: HistoryPanelProps) {
  const { convertTemp, getUnitSymbol } = useTempUnit();
  const isTemperature = metric === "temp";
  
  const recentYears = history.slice(-20);
  const rawValues = recentYears.map(h => h.values[metric] || 0);
  const values = isTemperature ? rawValues.map(convertTemp) : rawValues;
  const trend = values.length >= 2 
    ? (values[values.length - 1] > values[0] ? "increasing" : "decreasing")
    : "stable";

  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const range = max - min || 1;

  const unit = isTemperature ? getUnitSymbol() : (metric === "rain" ? "%" : "");
  const title = targetDate 
    ? `${metricLabel}: Past ${recentYears.length} Years for ${targetDate} ±${windowDays} Days`
    : `${metricLabel}: Past ${recentYears.length} Years`;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          {title}
          {trend !== "stable" && (
            trend === "increasing" 
              ? <TrendingUp className="h-4 w-4 text-chart-3 ml-auto" />
              : <TrendingDown className="h-4 w-4 text-chart-1 ml-auto" />
          )}
        </CardTitle>
        <CardDescription className="text-xs">
          Historical climatology trend analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="relative">
            <div className="flex items-end justify-between gap-1 h-40">
              {recentYears.map((entry, idx) => {
                const displayValue = isTemperature ? convertTemp(entry.values[metric] || 0) : (entry.values[metric] || 0);
                const height = ((values[idx] - min) / range) * 100;
                const showLabel = entry.year % 2 === 0;
                return (
                  <div key={entry.year} className="flex-1 flex flex-col items-center gap-1">
                    <div 
                      className="w-full bg-primary rounded-sm transition-all hover-elevate"
                      style={{ height: `${Math.max(height, 5)}%` }}
                      title={`${entry.year}: ${displayValue.toFixed(1)}${unit}`}
                    />
                    {showLabel && (
                      <span className="text-xs text-muted-foreground rotate-45 origin-top-left mt-2 whitespace-nowrap">
                        {entry.year}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="text-xs text-muted-foreground text-center mt-8">
              Year
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border text-center">
            <div>
              <div className="text-xs text-muted-foreground">Min</div>
              <div className="text-sm font-medium">
                {min.toFixed(1)}{unit}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Avg</div>
              <div className="text-sm font-medium">
                {(values.reduce((a, b) => a + b, 0) / values.length).toFixed(1)}{unit}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Max</div>
              <div className="text-sm font-medium">
                {max.toFixed(1)}{unit}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
