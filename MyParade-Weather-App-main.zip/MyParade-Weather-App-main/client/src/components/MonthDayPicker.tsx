import { useState } from "react";
import { Calendar, Clock } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

interface MonthDayPickerProps {
  onDateChange?: (month: number, day?: number, hour?: number, windowDays?: number) => void;
}

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export default function MonthDayPicker({ onDateChange }: MonthDayPickerProps) {
  const [month, setMonth] = useState("6");
  const [day, setDay] = useState("");
  const [hour, setHour] = useState("12");
  const [windowDays, setWindowDays] = useState("7");

  const handleMonthChange = (newMonth: string) => {
    setMonth(newMonth);
    const dayNum = day ? parseInt(day) : undefined;
    const hourNum = parseInt(hour);
    const windowNum = parseInt(windowDays);
    onDateChange?.(parseInt(newMonth), dayNum, hourNum, windowNum);
  };

  const handleDayChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newDay = e.target.value;
    setDay(newDay);
    const dayNum = newDay ? parseInt(newDay) : undefined;
    const hourNum = parseInt(hour);
    const windowNum = parseInt(windowDays);
    onDateChange?.(parseInt(month), dayNum, hourNum, windowNum);
  };

  const handleHourChange = (newHour: string) => {
    setHour(newHour);
    const dayNum = day ? parseInt(day) : undefined;
    const hourNum = parseInt(newHour);
    const windowNum = parseInt(windowDays);
    onDateChange?.(parseInt(month), dayNum, hourNum, windowNum);
  };

  const handleWindowChange = (newWindow: string) => {
    setWindowDays(newWindow);
    const dayNum = day ? parseInt(day) : undefined;
    const hourNum = parseInt(hour);
    const windowNum = parseInt(newWindow);
    onDateChange?.(parseInt(month), dayNum, hourNum, windowNum);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <Label htmlFor="target-month" className="text-sm font-medium mb-2 block">
            Target Month
          </Label>
          <Select value={month} onValueChange={handleMonthChange}>
            <SelectTrigger id="target-month" data-testid="select-month">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {months.map((m, idx) => (
                <SelectItem key={idx} value={String(idx + 1)}>
                  {m}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="target-day" className="text-sm font-medium mb-2 block">
            Target Day (Optional)
          </Label>
          <Input
            id="target-day"
            type="number"
            min="1"
            max="31"
            placeholder="Leave blank for entire month"
            value={day}
            onChange={handleDayChange}
            data-testid="input-day"
          />
        </div>

        <div>
          <Label htmlFor="target-hour" className="text-sm font-medium mb-2 block">
            Target Hour
          </Label>
          <Select value={hour} onValueChange={handleHourChange}>
            <SelectTrigger id="target-hour" data-testid="select-hour">
              <Clock className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Array.from({ length: 24 }, (_, i) => (
                <SelectItem key={i} value={String(i)}>
                  {i.toString().padStart(2, '0')}:00
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="window-days" className="text-sm font-medium mb-2 block">
          Climatology Window (±days)
        </Label>
        <Select value={windowDays} onValueChange={handleWindowChange}>
          <SelectTrigger id="window-days" data-testid="select-window">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="3">±3 days</SelectItem>
            <SelectItem value="7">±7 days</SelectItem>
            <SelectItem value="15">±15 days</SelectItem>
            <SelectItem value="30">±30 days</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground mt-1">
          Analyzes {months[parseInt(month) - 1]} {day || 'all days'} at {hour.padStart(2, '0')}:00 ± {windowDays} days across 30+ years
        </p>
      </div>
    </div>
  );
}
