import PlannerTips from '../PlannerTips';

export default function PlannerTipsExample() {
  const mockProbabilities = {
    rain: 75,
    heavyRain: 25,
    avgTemp: 32,
    heatWave: 35,
    veryCold: 5,
    veryWindy: 45,
    cloudCover: 70,
    snow: 1,
    uncomfortable: 55
  };

  return (
    <div className="p-6 max-w-2xl">
      <PlannerTips probabilities={mockProbabilities} />
    </div>
  );
}
