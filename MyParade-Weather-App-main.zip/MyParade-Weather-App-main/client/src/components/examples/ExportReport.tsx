import ExportReport from '../ExportReport';

export default function ExportReportExample() {
  return (
    <div className="p-6 max-w-2xl">
      <ExportReport />
    </div>
  );
}
