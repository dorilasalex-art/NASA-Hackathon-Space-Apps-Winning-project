import HistoryPanel from '../HistoryPanel';

export default function HistoryPanelExample() {
  const mockHistory = [
    { year: 2014, values: { rain: 55, temp: 27.2 } },
    { year: 2015, values: { rain: 58, temp: 27.5 } },
    { year: 2016, values: { rain: 62, temp: 28.1 } },
    { year: 2017, values: { rain: 60, temp: 28.3 } },
    { year: 2018, values: { rain: 65, temp: 28.5 } },
    { year: 2019, values: { rain: 63, temp: 28.8 } },
    { year: 2020, values: { rain: 67, temp: 29.1 } },
    { year: 2021, values: { rain: 64, temp: 29.0 } },
    { year: 2022, values: { rain: 68, temp: 29.3 } },
    { year: 2023, values: { rain: 70, temp: 29.5 } },
  ];

  return (
    <div className="p-6 max-w-2xl space-y-4">
      <HistoryPanel history={mockHistory} metric="rain" />
      <HistoryPanel history={mockHistory} metric="temp" />
    </div>
  );
}
