import LocationPicker from '../LocationPicker';

export default function LocationPickerExample() {
  return (
    <div className="p-6 max-w-2xl">
      <LocationPicker 
        onLocationChange={(lat, lon, name) => 
          console.log('Location changed:', { lat, lon, name })
        } 
      />
    </div>
  );
}
