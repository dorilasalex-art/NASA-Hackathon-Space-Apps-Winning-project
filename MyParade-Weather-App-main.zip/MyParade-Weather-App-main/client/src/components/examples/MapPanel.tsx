import MapPanel from '../MapPanel';

export default function MapPanelExample() {
  return (
    <div className="p-6 max-w-4xl">
      <MapPanel lat={28.5383} lon={-81.3792} />
    </div>
  );
}
