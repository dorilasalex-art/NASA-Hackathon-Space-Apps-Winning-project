import ClimatologyCard from '../ClimatologyCard';

export default function ClimatologyCardExample() {
  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <ClimatologyCard
        condition="rain"
        probability={65}
        wilsonCI={[58, 72]}
        definition="≥1mm precipitation"
        drivers={{ "Historical days": 19, "Total years": 30 }}
        trend="stable"
        timeseries={[60, 62, 65, 68, 65, 63, 65]}
      />
      <ClimatologyCard
        condition="heavyRain"
        probability={15}
        wilsonCI={[10, 22]}
        definition="≥P95 or ≥20mm/day"
        drivers={{ "P95 threshold": 22.5, "Max observed": 45.2 }}
        trend="increasing"
        timeseries={[10, 12, 13, 15, 17, 16, 15]}
      />
      <ClimatologyCard
        condition="avgTemp"
        probability={28.5}
        wilsonCI={[27.2, 29.8]}
        definition="Mean daily temperature"
        avgValue={28.5}
        drivers={{ "Historical mean": 28.5, "Std dev": 2.1 }}
        trend="increasing"
        timeseries={[26, 27, 28, 28.5, 29, 28.8, 28.5]}
      />
      <ClimatologyCard
        condition="heatWave"
        probability={22}
        wilsonCI={[16, 29]}
        definition="≥2 consecutive P90 days"
        percentile={90}
        drivers={{ "P90 Tmax": 35.2, "Consecutive": 2 }}
        trend="increasing"
        timeseries={[18, 19, 20, 22, 24, 23, 22]}
      />
      <ClimatologyCard
        condition="veryCold"
        probability={8}
        wilsonCI={[4, 14]}
        definition="P10 Tmin ≤5°C"
        percentile={10}
        drivers={{ "P10 Tmin": 5.2, "Historical": 2 }}
        trend="decreasing"
        timeseries={[12, 10, 9, 8, 7, 8, 8]}
      />
      <ClimatologyCard
        condition="veryWindy"
        probability={35}
        wilsonCI={[28, 42]}
        definition="Wind ≥10 m/s"
        drivers={{ "P90 wind": 12.5, "Mean": 7.8 }}
        trend="stable"
        timeseries={[32, 34, 35, 36, 35, 34, 35]}
      />
      <ClimatologyCard
        condition="cloudCover"
        probability={70}
        wilsonCI={[63, 77]}
        definition="Cloud cover ≥70%"
        drivers={{ "Mean cover": 72, "Clear days": 9 }}
        trend="stable"
        timeseries={[68, 69, 70, 72, 71, 70, 70]}
      />
      <ClimatologyCard
        condition="snow"
        probability={2}
        wilsonCI={[0, 6]}
        definition="Snow occurrence"
        drivers={{ "Historical events": 1, "Years": 30 }}
        trend="decreasing"
        timeseries={[3, 2.5, 2, 2, 1.5, 2, 2]}
      />
      <ClimatologyCard
        condition="uncomfortable"
        probability={45}
        wilsonCI={[38, 52]}
        definition="HI ≥32°C or WC ≤-10°C"
        drivers={{ "Heat Index": 34.2, "RH": 78 }}
        trend="increasing"
        timeseries={[40, 42, 44, 45, 47, 46, 45]}
      />
    </div>
  );
}
