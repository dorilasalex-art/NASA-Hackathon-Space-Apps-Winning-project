import TimeWindow from '../TimeWindow';

export default function TimeWindowExample() {
  return (
    <div className="p-6 max-w-2xl">
      <TimeWindow 
        onTimeChange={(start, end, resolution) => 
          console.log('Time changed:', { start, end, resolution })
        } 
      />
    </div>
  );
}
