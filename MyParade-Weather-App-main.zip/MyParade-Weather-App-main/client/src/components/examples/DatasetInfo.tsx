import DatasetInfo from '../DatasetInfo';

export default function DatasetInfoExample() {
  const mockDatasets = [
    {
      name: "GPM IMERG",
      version: "V07B",
      source: "NASA GES DISC",
      temporalResolution: "30-min",
      spatialResolution: "0.1° × 0.1°",
      coverage: "1998-present"
    },
    {
      name: "MERRA-2",
      version: "5.12.4",
      source: "NASA GMAO",
      temporalResolution: "1-hourly",
      spatialResolution: "0.5° × 0.625°",
      coverage: "1980-present"
    },
    {
      name: "GLDAS-2.1",
      version: "2.1",
      source: "NASA GES DISC",
      temporalResolution: "3-hourly",
      spatialResolution: "0.25° × 0.25°",
      coverage: "2000-present"
    }
  ];

  return (
    <div className="p-6 max-w-2xl">
      <DatasetInfo 
        datasets={mockDatasets} 
        computedAt={new Date().toISOString()}
        cacheHit={true}
      />
    </div>
  );
}
