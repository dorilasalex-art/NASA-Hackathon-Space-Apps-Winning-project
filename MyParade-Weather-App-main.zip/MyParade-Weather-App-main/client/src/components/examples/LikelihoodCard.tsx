import LikelihoodCard from '../LikelihoodCard';

export default function LikelihoodCardExample() {
  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
      <LikelihoodCard
        condition="veryHot"
        probability={73}
        confidence={[61, 82]}
        drivers={{ "Tmax °C": 36.8, "RH %": 44 }}
        timeseries={[65, 68, 70, 73, 75, 73, 71]}
      />
      <LikelihoodCard
        condition="veryCold"
        probability={12}
        confidence={[8, 18]}
        drivers={{ "Tmin °C": 15.2, "Wind chill °C": 12.8 }}
        timeseries={[15, 14, 12, 11, 10, 12, 13]}
      />
      <LikelihoodCard
        condition="veryWindy"
        probability={45}
        confidence={[38, 52]}
        drivers={{ "Wind m/s": 8.5, "Gust m/s": 12.3 }}
        timeseries={[40, 42, 45, 48, 47, 45, 43]}
      />
      <LikelihoodCard
        condition="veryWet"
        probability={88}
        confidence={[82, 93]}
        drivers={{ "Precip mm": 12.5, "Rate mm/h": 3.2 }}
        timeseries={[75, 80, 85, 88, 90, 88, 85]}
      />
      <LikelihoodCard
        condition="veryUncomfortable"
        probability={61}
        confidence={[54, 68]}
        drivers={{ "Heat Index °C": 34.2, "RH %": 78 }}
        timeseries={[55, 58, 60, 61, 63, 62, 60]}
      />
    </div>
  );
}
