import MonthDayPicker from '../MonthDayPicker';

export default function MonthDayPickerExample() {
  return (
    <div className="p-6 max-w-2xl">
      <MonthDayPicker 
        onDateChange={(month, day, windowDays) => 
          console.log('Date configured:', { month, day, windowDays })
        } 
      />
    </div>
  );
}
