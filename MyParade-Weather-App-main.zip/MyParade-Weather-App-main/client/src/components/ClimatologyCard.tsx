import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Thermometer, 
  Snowflake, 
  Wind, 
  CloudRain, 
  AlertTriangle, 
  Cloud
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useTempUnit } from "@/lib/tempContext";

interface ClimatologyCardProps {
  condition: "rain" | "heavyRain" | "avgTemp" | "heatWave" | "veryCold" | "veryWindy" | "cloudCover" | "snow" | "uncomfortable";
  probability: number | null;
  wilsonCI: [number, number] | null;
  definition: string;
  drivers: Record<string, number> | null;
  avgValue?: number | null;
  percentile?: number;
}

const conditionConfig = {
  rain: {
    title: "Rain Probability",
    icon: CloudRain,
  },
  heavyRain: {
    title: "Heavy Rain",
    icon: CloudRain,
  },
  avgTemp: {
    title: "Avg Temperature",
    icon: Thermometer,
  },
  heatWave: {
    title: "Heat Wave Risk",
    icon: Thermometer,
  },
  veryCold: {
    title: "Very Cold",
    icon: Snowflake,
  },
  veryWindy: {
    title: "Very Windy",
    icon: Wind,
  },
  cloudCover: {
    title: "Cloud Cover",
    icon: Cloud,
  },
  snow: {
    title: "Snow Probability",
    icon: Snowflake,
  },
  uncomfortable: {
    title: "Uncomfortable",
    icon: AlertTriangle,
  },
};

const getColorForProbability = (prob: number) => {
  if (prob <= 33) return "text-green-500";
  if (prob <= 66) return "text-yellow-500";
  return "text-red-500";
};

export default function ClimatologyCard({
  condition,
  probability,
  wilsonCI,
  definition,
  drivers,
  avgValue,
  percentile,
}: ClimatologyCardProps) {
  const config = conditionConfig[condition];
  const Icon = config.icon;
  const { convertTemp, getUnitSymbol } = useTempUnit();

  const isTemperature = condition === "avgTemp";
  
  const hasData = isTemperature 
    ? avgValue !== null && avgValue !== undefined
    : probability !== null && probability !== undefined;
  
  const displayValue = hasData
    ? (isTemperature && avgValue !== null && avgValue !== undefined
        ? `${convertTemp(avgValue).toFixed(1)}${getUnitSymbol()}`
        : `${probability!.toFixed(1)}%`)
    : "--";
  
  const colorClass = probability !== null ? getColorForProbability(probability) : "text-muted-foreground";

  const tooltipContent = (
    <div className="space-y-2 max-w-xs">
      <p className="font-semibold">{definition}</p>
      {percentile && (
        <p className="text-xs">P{percentile} climatology threshold</p>
      )}
      {drivers && (
        <div className="text-xs space-y-1">
          {Object.entries(drivers).map(([key, value]) => (
            <div key={key}>
              {key}: {value.toFixed(1)}
            </div>
          ))}
        </div>
      )}
      {!hasData && (
        <p className="text-xs text-muted-foreground">Data not available for this month</p>
      )}
    </div>
  );

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Card className="hover-elevate cursor-help" data-testid={`card-${condition}`}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Icon className="h-5 w-5" />
              {config.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="text-center">
              <div 
                className={`text-6xl font-bold ${colorClass}`} 
                data-testid={`text-value-${condition}`}
              >
                {displayValue}
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                {hasData && wilsonCI
                  ? (isTemperature 
                      ? `95% CI: ${convertTemp(wilsonCI[0]).toFixed(1)}${getUnitSymbol()} - ${convertTemp(wilsonCI[1]).toFixed(1)}${getUnitSymbol()}`
                      : `95% CI: ${wilsonCI[0].toFixed(1)}% - ${wilsonCI[1].toFixed(1)}%`)
                  : "No confidence interval"
                }
              </div>
            </div>
          </CardContent>
        </Card>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-sm">
        {tooltipContent}
      </TooltipContent>
    </Tooltip>
  );
}
