import { Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTempUnit } from "@/lib/tempContext";

export default function Header() {
  const { unit, toggleUnit } = useTempUnit();
  const lastUpdated = new Date().toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZoneName: "short",
  });

  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <h1
          className="text-2xl font-bold text-foreground"
          data-testid="text-app-title"
        >
          MyParade Weather App
        </h1>
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={toggleUnit}
            className="font-mono min-w-[3.5rem]"
            data-testid="button-temp-unit-toggle"
          >
            {unit === "C" ? "°C" : "°F"}
          </Button>
          <div
            className="flex items-center gap-2 text-sm text-muted-foreground"
            data-testid="text-last-updated"
          >
            <Clock className="h-4 w-4" />
            <span>Last updated: {lastUpdated}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
