import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileJson, Share2, FileImage } from "lucide-react";

export default function ExportReport() {
  const handleExportPDF = () => {
    console.log('Exporting PDF report...');
  };

  const handleExportJSON = () => {
    console.log('Exporting JSON data...');
  };

  const handleShare = () => {
    console.log('Copying shareable URL...');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Download className="h-5 w-5" />
          Export & Share
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-wrap gap-2">
        <Button 
          onClick={handleExportPDF} 
          className="flex-1 min-w-[140px]"
          data-testid="button-export-pdf"
        >
          <FileImage className="h-4 w-4 mr-2" />
          Export PDF
        </Button>
        <Button 
          onClick={handleExportJSON} 
          variant="outline" 
          className="flex-1 min-w-[140px]"
          data-testid="button-export-json"
        >
          <FileJson className="h-4 w-4 mr-2" />
          Export JSON
        </Button>
        <Button 
          onClick={handleShare} 
          variant="outline" 
          className="flex-1 min-w-[140px]"
          data-testid="button-share-url"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share URL
        </Button>
      </CardContent>
    </Card>
  );
}
