import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Database, AlertCircle, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Dataset {
  name: string;
  version: string;
  source: string;
  temporalResolution: string;
  spatialResolution: string;
  coverage: string;
}

interface DatasetInfoProps {
  datasets: Dataset[];
  computedAt: string;
  cacheHit?: boolean;
}

export default function DatasetInfo({ datasets, computedAt, cacheHit }: DatasetInfoProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Database className="h-5 w-5" />
          Dataset Information
          {cacheHit && (
            <Badge variant="outline" className="ml-auto">
              Cached
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-sm">
            <strong>Climatology, not forecast.</strong> These probabilities are based on {datasets.length > 0 ? '30+' : ''} years of NASA Earth observations.
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          {datasets.map((dataset, idx) => (
            <div key={idx} className="border border-border rounded-lg p-3 space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-medium text-sm">{dataset.name}</div>
                  <div className="text-xs text-muted-foreground">{dataset.source}</div>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {dataset.version}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                <div>
                  <Info className="h-3 w-3 inline mr-1" />
                  Temporal: {dataset.temporalResolution}
                </div>
                <div>
                  <Info className="h-3 w-3 inline mr-1" />
                  Spatial: {dataset.spatialResolution}
                </div>
              </div>
              <div className="text-xs text-muted-foreground">
                Coverage: {dataset.coverage}
              </div>
            </div>
          ))}
        </div>

        <div className="text-xs text-muted-foreground text-center pt-2 border-t border-border">
          Computed: {new Date(computedAt).toLocaleString()}
        </div>
      </CardContent>
    </Card>
  );
}
