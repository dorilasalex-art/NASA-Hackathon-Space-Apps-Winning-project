import os
import sys
import datetime
from datetime import datetime as dt
import pandas as pd
import requests
from io import StringIO
from requests.auth import HTTPBasicAuth

# Get credentials from environment variables
USERNAME = os.getenv("juanpablandon", "")
PASSWORD = os.getenv("Cristinaaguilera1@", "")

# NASA GES DISC HTTP Services base URL
NASA_BASE_URL = "https://disc.gsfc.nasa.gov/daac-bin/OTF/HTTP_services.cgi"


def save_raw_csv(data: str, location: str, dataset: str, year: int, month: int, day: int, hour: int) -> str:
    """
    Save raw API response data to a CSV file with timestamp.
    
    Args:
        data: Raw CSV data as string
        location: Location name (e.g., 'Tampa')
        dataset: Dataset name (e.g., 'gldas_temp', 'gpm_precip', 'merra2_wind')
        year, month, day, hour: Date/time of the data
        
    Returns:
        Path to the saved file
    """
    # Create directory if it doesn't exist
    output_dir = os.path.join(os.getcwd(), "Backend", "data", "raw_api_responses")
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate filename with timestamp
    timestamp = dt.now().strftime("%Y%m%d_%H%M%S")
    location_clean = location.lower().replace(" ", "_")
    filename = f"{location_clean}_{dataset}_{year}{month:02d}{day:02d}_{hour:02d}h_{timestamp}.csv"
    filepath = os.path.join(output_dir, filename)
    
    # Save the data
    with open(filepath, 'w') as f:
        f.write(data)
    
    print(f"Saved raw CSV to: {filepath}", file=sys.stderr)
    return filepath


def fetch_gldas_temperature(lat: float, lon: float, year: int, month: int, day: int, hour: int, location: str = "Unknown") -> pd.DataFrame:
    """
    Fetch GLDAS temperature data from NASA GES DISC.
    
    Args:
        lat, lon: Coordinates
        year, month, day, hour: Date and time
        location: Location name for filename
        
    Returns:
        DataFrame with temperature data
    """
    # Round hour to nearest 3-hour interval (GLDAS is 3-hourly: 00, 03, 06, 09, 12, 15, 18, 21)
    rounded_hour = (hour // 3) * 3
    
    # Convert to day of year
    date = datetime.datetime(year, month, day)
    doy = date.timetuple().tm_yday
    
    # Construct bounding box (±0.05 degrees)
    bbox = f"{lon-0.05},{lat-0.02},{lon+0.05},{lat+0.06}"
    
    # Construct filename path
    filename = f"/data/GLDAS_NOAH025_3H.2.1/{year}/{doy:03d}/GLDAS_NOAH025_3H.A{year}{doy:03d}.{rounded_hour:02d}00.021.nc4"
    
    # Build URL
    params = {
        'FILENAME': filename,
        'BBOX': bbox,
        'VARIABLES': 'Tair_f_inst',
        'FORMAT': 'CSV'
    }
    
    print(f"Fetching GLDAS temperature for {year}/{month:02d}/{day:02d} {rounded_hour:02d}:00", file=sys.stderr)
    
    # Make authenticated request
    response = requests.get(NASA_BASE_URL, params=params, auth=HTTPBasicAuth(USERNAME, PASSWORD))
    response.raise_for_status()
    
    # Save raw response
    save_raw_csv(response.text, location, "gldas_temp", year, month, day, rounded_hour)
    
    # Parse CSV
    df = pd.read_csv(StringIO(response.text))
    return df


def fetch_gpm_precipitation(lat: float, lon: float, year: int, month: int, day: int, hour: int, location: str = "Unknown") -> pd.DataFrame:
    """
    Fetch GPM IMERG precipitation data from NASA GES DISC.
    
    Args:
        lat, lon: Coordinates
        year, month, day, hour: Date and time
        location: Location name for filename
        
    Returns:
        DataFrame with precipitation data
    """
    # GPM IMERG is half-hourly, round to nearest 30 minutes
    rounded_hour = hour
    rounded_minute = 0  # Use top of hour
    
    # Convert to day of year
    date = datetime.datetime(year, month, day)
    doy = date.timetuple().tm_yday
    
    # Construct bounding box
    bbox = f"{lon-0.05},{lat-0.02},{lon+0.05},{lat+0.06}"
    
    # Construct filename path for GPM IMERG
    filename = f"/data/GPM_L3/GPM_3IMERGHH.07/{year}/{doy:03d}/3B-HHR.MS.MRG.3IMERG.{year}{month:02d}{day:02d}-S{rounded_hour:02d}{rounded_minute:02d}00-E{rounded_hour:02d}{(rounded_minute+29):02d}59.{rounded_hour*60+rounded_minute:04d}.V07B.HDF5"
    
    # Build URL
    params = {
        'FILENAME': filename,
        'BBOX': bbox,
        'VARIABLES': 'precipitation',
        'FORMAT': 'CSV'
    }
    
    print(f"Fetching GPM precipitation for {year}/{month:02d}/{day:02d} {rounded_hour:02d}:00", file=sys.stderr)
    
    # Make authenticated request
    response = requests.get(NASA_BASE_URL, params=params, auth=HTTPBasicAuth(USERNAME, PASSWORD))
    response.raise_for_status()
    
    # Save raw response
    save_raw_csv(response.text, location, "gpm_precip", year, month, day, rounded_hour)
    
    # Parse CSV
    df = pd.read_csv(StringIO(response.text))
    return df


def fetch_merra2_wind(lat: float, lon: float, year: int, month: int, day: int, hour: int, location: str = "Unknown") -> pd.DataFrame:
    """
    Fetch MERRA-2 wind data from NASA GES DISC.
    
    Args:
        lat, lon: Coordinates
        year, month, day, hour: Date and time
        location: Location name for filename
        
    Returns:
        DataFrame with wind data
    """
    # MERRA-2 is hourly
    
    # Construct bounding box
    bbox = f"{lon-0.05},{lat-0.02},{lon+0.05},{lat+0.06}"
    
    # Construct filename path for MERRA-2
    filename = f"/data/MERRA2/M2T1NXSLV.5.12.4/{year}/{month:02d}/MERRA2_400.tavg1_2d_slv_Nx.{year}{month:02d}{day:02d}.nc4"
    
    # Build URL
    params = {
        'FILENAME': filename,
        'BBOX': bbox,
        'VARIABLES': 'U10M,V10M',  # 10-meter wind components
        'FORMAT': 'CSV'
    }
    
    print(f"Fetching MERRA-2 wind for {year}/{month:02d}/{day:02d} {hour:02d}:00", file=sys.stderr)
    
    # Make authenticated request
    response = requests.get(NASA_BASE_URL, params=params, auth=HTTPBasicAuth(USERNAME, PASSWORD))
    response.raise_for_status()
    
    # Save raw response
    save_raw_csv(response.text, location, "merra2_wind", year, month, day, hour)
    
    # Parse CSV
    df = pd.read_csv(StringIO(response.text))
    return df


def fetch_historical_data(lat: float = None, lon: float = None, target_month: int = 6, target_day: int = 15, target_hour: int = 12, location: str = "Unknown", start_year: int = None) -> dict:
    """
    Fetch 10 years of historical data for a specific month/day/hour.
    
    Args:
        lat, lon: Coordinates (optional if location name is provided)
        target_month, target_day: Target date (month and day)
        target_hour: Target hour (0-23)
        location: Location name
        start_year: Optional start year (defaults to 10 years ago)
        
    Returns:
        Dictionary with:
            - 'temperature_data': Combined DataFrame with all years
            - 'precipitation_data': Combined DataFrame with all years
            - 'wind_data': Combined DataFrame with all years
            - 'years_fetched': List of successfully fetched years
            - 'saved_files': List of saved CSV file paths
    """
    # Look up coordinates from location name if not provided
    if lat is None or lon is None:
        location_coords = {
            "Tampa": (28.06, -82.41),
            "Orlando": (28.55, -81.20),
            "Miami": (25.76, -80.38)
        }
        if location in location_coords:
            lat, lon = location_coords[location]
        else:
            raise ValueError(f"Unknown location: {location}. Provide lat/lon coordinates.")
    
    current_year = datetime.datetime.now().year
    if start_year is None:
        start_year = current_year - 10
    
    all_temp_data = []
    all_precip_data = []
    all_wind_data = []
    years_fetched = []
    saved_files = []
    
    print(f"Fetching historical data for {location}...", file=sys.stderr)
    
    for year in range(start_year, current_year + 1):
        try:
            print(f"Fetching data for {location} - {year}/{target_month:02d}/{target_day:02d} {target_hour:02d}:00", file=sys.stderr)
            
            # Fetch temperature data
            try:
                temp_df = fetch_gldas_temperature(lat, lon, year, target_month, target_day, target_hour, location)
                temp_df['year'] = year
                all_temp_data.append(temp_df)
            except Exception as e:
                print(f"Error fetching temperature for {year}: {e}", file=sys.stderr)
            
            # Fetch precipitation data
            try:
                precip_df = fetch_gpm_precipitation(lat, lon, year, target_month, target_day, target_hour, location)
                precip_df['year'] = year
                all_precip_data.append(precip_df)
            except Exception as e:
                print(f"Error fetching precipitation for {year}: {e}", file=sys.stderr)
            
            # Fetch wind data
            try:
                wind_df = fetch_merra2_wind(lat, lon, year, target_month, target_day, target_hour, location)
                wind_df['year'] = year
                all_wind_data.append(wind_df)
            except Exception as e:
                print(f"Error fetching wind for {year}: {e}", file=sys.stderr)
            
            years_fetched.append(year)
            
        except Exception as e:
            print(f"Error fetching data for {year}: {e}", file=sys.stderr)
            continue
    
    # Combine all data
    temperature_data = pd.concat(all_temp_data, ignore_index=True) if all_temp_data else pd.DataFrame()
    precipitation_data = pd.concat(all_precip_data, ignore_index=True) if all_precip_data else pd.DataFrame()
    wind_data = pd.concat(all_wind_data, ignore_index=True) if all_wind_data else pd.DataFrame()
    
    print(f"Fetched {len(years_fetched)} years of data", file=sys.stderr)
    print(f"Saved {len(saved_files)} CSV files", file=sys.stderr)
    
    return {
        'temperature_data': temperature_data,
        'precipitation_data': precipitation_data,
        'wind_data': wind_data,
        'years_fetched': years_fetched,
        'saved_files': saved_files
    }


if __name__ == "__main__":
    # Test with Tampa coordinates
    result = fetch_historical_data(
        lat=28.06,
        lon=-82.41,
        target_month=6,
        target_day=15,
        target_hour=12,
        location="Tampa"
    )
    
    print(f"\n=== Results ===", file=sys.stderr)
    print(f"Years fetched: {result['years_fetched']}", file=sys.stderr)
    print(f"Temperature records: {len(result['temperature_data'])}", file=sys.stderr)
    print(f"Precipitation records: {len(result['precipitation_data'])}", file=sys.stderr)
    print(f"Wind records: {len(result['wind_data'])}", file=sys.stderr)
