#!/usr/bin/env python3
import sys
import json
import requests
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# City coordinates
CITY_COORDS = {
    "Tampa": {"lat": 28.06, "lon": -82.41},
    "Orlando": {"lat": 28.55, "lon": -81.20},
    "Miami": {"lat": 25.76, "lon": -80.19}
}

def fetch_historical_data(location, target_month, target_day, years_back=10):
    """Fetch historical weather data from Open-Meteo API for multiple years"""
    if location not in CITY_COORDS:
        raise ValueError(f"Location {location} not found in available cities")
    
    coords = CITY_COORDS[location]
    current_year = datetime.now().year
    
    all_data = []
    
    # Fetch data for the past N years
    for year in range(current_year - years_back, current_year):
        try:
            # Create date range for the specific month/day ±3 days window
            target_date = datetime(year, target_month, target_day)
            start_date = (target_date - timedelta(days=3)).strftime('%Y-%m-%d')
            end_date = (target_date + timedelta(days=3)).strftime('%Y-%m-%d')
            
            # Open-Meteo Historical Weather API (free, no key required)
            url = "https://archive-api.open-meteo.com/v1/archive"
            params = {
                "latitude": coords["lat"],
                "longitude": coords["lon"],
                "start_date": start_date,
                "end_date": end_date,
                "hourly": "temperature_2m,precipitation,wind_speed_10m",
                "timezone": "America/New_York"
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # Convert to DataFrame
            if 'hourly' in data:
                hourly = data['hourly']
                year_df = pd.DataFrame({
                    'datetime': pd.to_datetime(hourly['time']),
                    'temperature': hourly['temperature_2m'],
                    'precipitation': hourly['precipitation'],
                    'wind_speed': hourly['wind_speed_10m']
                })
                all_data.append(year_df)
                
        except Exception as e:
            print(f"Warning: Could not fetch data for {year}: {str(e)}", file=sys.stderr)
            continue
    
    if not all_data:
        return None
    
    # Combine all years
    combined_df = pd.concat(all_data, ignore_index=True)
    return combined_df

def filter_data_by_datetime(df, target_month, target_day, target_hour):
    """Filter data for specific month, day, and hour across all years"""
    if df is None or len(df) == 0:
        return pd.DataFrame()
    
    # Filter by month and day
    filtered = df[
        (df['datetime'].dt.month == target_month) & 
        (df['datetime'].dt.day == target_day)
    ]
    
    # Filter by hour (with some tolerance for hourly data)
    hour_tolerance = 1
    filtered = filtered[
        (filtered['datetime'].dt.hour >= target_hour - hour_tolerance) &
        (filtered['datetime'].dt.hour <= target_hour + hour_tolerance)
    ]
    
    return filtered

def calculate_statistics(data):
    """Calculate climatology statistics from the filtered data"""
    if len(data) == 0:
        return None
    
    # Temperature statistics
    temp_mean = data['temperature'].mean()
    temp_std = data['temperature'].std()
    
    # Wind statistics
    wind_mean = data['wind_speed'].mean()
    wind_p90 = data['wind_speed'].quantile(0.90) if len(data) > 1 else wind_mean
    very_windy_prob = (data['wind_speed'] >= 10.0).mean() * 100  # ≥10 m/s
    
    # Precipitation statistics
    precip_mean = data['precipitation'].mean()
    rain_prob = (data['precipitation'] >= 1.0).mean() * 100  # ≥1mm
    heavy_rain_prob = (data['precipitation'] >= 20.0).mean() * 100  # ≥20mm
    
    return {
        'temperature': {
            'mean': float(temp_mean),
            'std': float(temp_std),
            'count': int(len(data))
        },
        'wind': {
            'mean': float(wind_mean),
            'p90': float(wind_p90),
            'very_windy_prob': float(very_windy_prob),
            'count': int(len(data))
        },
        'precipitation': {
            'mean': float(precip_mean),
            'rain_prob': float(rain_prob),
            'heavy_rain_prob': float(heavy_rain_prob),
            'count': int(len(data))
        }
    }

def process_climatology(location, target_month, target_day, target_hour):
    """Main processing function - fetches from Open-Meteo API"""
    try:
        # Fetch historical data from API
        df = fetch_historical_data(location, target_month, target_day, years_back=10)
        
        if df is None:
            return {
                'success': False,
                'message': f'Could not fetch API data for {location}',
                'data': None
            }
        
        # Filter by date and time
        filtered_data = filter_data_by_datetime(df, target_month, target_day, target_hour)
        
        # Calculate statistics
        stats = calculate_statistics(filtered_data)
        
        if stats is None:
            return {
                'success': False,
                'message': f'No data available for {location} on month {target_month}, day {target_day}, hour {target_hour}',
                'data': None
            }
        
        return {
            'success': True,
            'location': location,
            'target_month': target_month,
            'target_day': target_day,
            'target_hour': target_hour,
            'data_points': len(filtered_data),
            'statistics': stats
        }
        
    except Exception as e:
        return {
            'success': False,
            'message': str(e),
            'data': None
        }

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Process climatology data from Open-Meteo API')
    parser.add_argument('--location', required=True, help='Location name (Tampa, Orlando, or Miami)')
    parser.add_argument('--month', type=int, required=True, help='Target month (1-12)')
    parser.add_argument('--day', type=int, required=True, help='Target day (1-31)')
    parser.add_argument('--hour', type=int, required=True, help='Target hour (0-23)')
    
    args = parser.parse_args()
    
    result = process_climatology(args.location, args.month, args.day, args.hour)
    print(json.dumps(result, indent=2))
