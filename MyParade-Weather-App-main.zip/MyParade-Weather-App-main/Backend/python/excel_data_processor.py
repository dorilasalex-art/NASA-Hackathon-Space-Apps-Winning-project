#!/usr/bin/env python3
import sys
import json
import pandas as pd
from datetime import datetime
import numpy as np

# File mapping
EXCEL_FILES = {
    "Tampa": "Backend/data/TAMPA_1.xlsx",
    "Orlando": "Backend/data/ORLANDO_all_aprils.xlsx",
    "Miami": "Backend/data/MIAMI_1_celsius.xlsx"
}

def load_excel_data(location):
    """Load Excel file for the specified location"""
    if location not in EXCEL_FILES:
        raise ValueError(f"Location {location} not found in available data")
    
    file_path = EXCEL_FILES[location]
    df = pd.read_excel(file_path)
    df['datetime'] = pd.to_datetime(df['datetime'])
    return df

def filter_data_by_datetime(df, target_month, target_day, target_hour):
    """Filter data for specific month, day, and hour across all years"""
    # Filter by month and day
    filtered = df[
        (df['datetime'].dt.month == target_month) & 
        (df['datetime'].dt.day == target_day)
    ]
    
    # Filter by hour (with some tolerance for 3-hourly data)
    # Allow ±1 hour tolerance to match 3-hourly data
    hour_tolerance = 1
    filtered = filtered[
        (df['datetime'].dt.hour >= target_hour - hour_tolerance) &
        (df['datetime'].dt.hour <= target_hour + hour_tolerance)
    ]
    
    return filtered

def calculate_statistics(data):
    """Calculate climatology statistics from the filtered data"""
    if len(data) == 0:
        return None
    
    # Temperature statistics
    temp_mean = data['temperature'].mean()
    temp_std = data['temperature'].std()
    
    # Wind statistics
    wind_mean = data['wind_speed'].mean()
    wind_p90 = data['wind_speed'].quantile(0.90) if len(data) > 1 else wind_mean
    very_windy_prob = (data['wind_speed'] >= 10.0).mean() * 100  # ≥10 m/s
    
    # Precipitation statistics
    precip_mean = data['precipitation'].mean()
    rain_prob = (data['precipitation'] >= 1.0).mean() * 100  # ≥1mm
    heavy_rain_prob = (data['precipitation'] >= 20.0).mean() * 100  # ≥20mm
    
    return {
        'temperature': {
            'mean': float(temp_mean),
            'std': float(temp_std),
            'count': int(len(data))
        },
        'wind': {
            'mean': float(wind_mean),
            'p90': float(wind_p90),
            'very_windy_prob': float(very_windy_prob),
            'count': int(len(data))
        },
        'precipitation': {
            'mean': float(precip_mean),
            'rain_prob': float(rain_prob),
            'heavy_rain_prob': float(heavy_rain_prob),
            'count': int(len(data))
        }
    }

def process_climatology(location, target_month, target_day, target_hour):
    """Main processing function"""
    try:
        # Load data
        df = load_excel_data(location)
        
        # Filter by date and time
        filtered_data = filter_data_by_datetime(df, target_month, target_day, target_hour)
        
        # Calculate statistics
        stats = calculate_statistics(filtered_data)
        
        if stats is None:
            return {
                'success': False,
                'message': f'No data available for {location} on month {target_month}, day {target_day}, hour {target_hour}',
                'data': None
            }
        
        return {
            'success': True,
            'location': location,
            'target_month': target_month,
            'target_day': target_day,
            'target_hour': target_hour,
            'data_points': len(filtered_data),
            'statistics': stats
        }
        
    except Exception as e:
        return {
            'success': False,
            'message': str(e),
            'data': None
        }

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='Process Excel climatology data')
    parser.add_argument('--location', required=True, help='Location name (Tampa, Orlando, or Miami)')
    parser.add_argument('--month', type=int, required=True, help='Target month (1-12)')
    parser.add_argument('--day', type=int, required=True, help='Target day (1-31)')
    parser.add_argument('--hour', type=int, required=True, help='Target hour (0-23)')
    
    args = parser.parse_args()
    
    result = process_climatology(args.location, args.month, args.day, args.hour)
    print(json.dumps(result, indent=2))
