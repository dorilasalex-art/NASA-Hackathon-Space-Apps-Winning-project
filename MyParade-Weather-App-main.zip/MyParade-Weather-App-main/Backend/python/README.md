# Weather Data Fetcher and Calculator

This directory contains Python scripts that fetch weather data from NASA APIs and calculate climatology statistics.

## Setup

### Python Dependencies

Install the required Python packages:

```bash
pip install requests pandas numpy openpyxl
```

### Environment Variables

You need to set NASA API credentials as environment variables:

```bash
export NASA_USERNAME="your_nasa_username"
export NASA_PASSWORD="your_nasa_password"
```

Or add them to your `.env` file (not committed to git):

```
NASA_USERNAME=your_nasa_username
NASA_PASSWORD=your_nasa_password
```

## Files

- **data_fetcher.py**: Fetches historical weather data from NASA APIs (GLDAS, MERRA-2, GPM) for the last 10 years
- **weather_calculations.py**: Processes weather data and calculates climatology statistics
- **main.py**: Main orchestration script that integrates data fetching and calculations

## Usage

The main script can be called directly:

```bash
python3 Backend/python/main.py --location Tampa --month 6 --day 15 --hour 12
```

Or it's automatically called by the Node.js backend via the `/api/fetch-weather` endpoint.

## Data Storage

Raw API responses are automatically saved as CSV files in:
```
Backend/data/raw_api_responses/
```

Each file is timestamped and includes location, dataset type, and date/time information.

## Supported Locations

- Orlando
- Tampa
- Miami

(Coordinates are predefined for each location in `data_fetcher.py`)
