#!/usr/bin/env python3
"""
Main script to fetch weather data from NASA APIs and calculate climatology statistics.
This script can be called from the Node.js backend.

Usage:
    python main.py --location Tampa --month 6 --day 15 --hour 12
"""

import argparse
import json
import sys
from data_fetcher import fetch_historical_data
from weather_calculations import WeatherCalculator


def main():
    """Main function to orchestrate data fetching and calculations."""
    parser = argparse.ArgumentParser(description='Fetch and analyze weather data')
    parser.add_argument('--location', type=str, required=True, 
                       help='Location name (Orlando, Tampa, or Miami)')
    parser.add_argument('--month', type=int, required=True,
                       help='Target month (1-12)')
    parser.add_argument('--day', type=int, required=True,
                       help='Target day (1-31)')
    parser.add_argument('--hour', type=int, default=12,
                       help='Target hour (0-23), default: 12')
    parser.add_argument('--start-year', type=int, default=None,
                       help='Start year for historical data, default: last 10 years')
    
    args = parser.parse_args()
    
    try:
        # Validate inputs
        if args.month < 1 or args.month > 12:
            raise ValueError("Month must be between 1 and 12")
        if args.day < 1 or args.day > 31:
            raise ValueError("Day must be between 1 and 31")
        if args.hour < 0 or args.hour > 23:
            raise ValueError("Hour must be between 0 and 23")
        
        # Step 1: Fetch historical data from NASA APIs
        print(f"Fetching historical data for {args.location}...", file=sys.stderr)
        api_data = fetch_historical_data(
            location=args.location,
            target_month=args.month,
            target_day=args.day,
            target_hour=args.hour,
            start_year=args.start_year
        )
        
        print(f"Fetched {api_data['years_fetched']} years of data", file=sys.stderr)
        print(f"Saved {len(api_data['saved_files'])} CSV files", file=sys.stderr)
        
        # Step 2: Process data with weather calculator
        print("Calculating climatology statistics...", file=sys.stderr)
        calculator = WeatherCalculator()
        results = calculator.process_api_data(api_data)
        
        # Step 3: Format results for frontend
        output = {
            'success': True,
            'location': results.get('location'),
            'target_date': results.get('target_date'),
            'target_hour': results.get('target_hour'),
            'years_analyzed': results.get('years_analyzed'),
            'saved_files': results.get('saved_files', []),
            'data': {
                'temperature': results.get('temperature', {}),
                'wind': results.get('wind', {}),
                'precipitation': results.get('precipitation', {})
            }
        }
        
        # Output as JSON to stdout
        print(json.dumps(output, indent=2))
        
    except Exception as e:
        # Output error as JSON
        error_output = {
            'success': False,
            'error': str(e),
            'error_type': type(e).__name__
        }
        print(json.dumps(error_output, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
