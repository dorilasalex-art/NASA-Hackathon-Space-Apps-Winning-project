"""
Weather Data Calculations

This module processes weather data from Excel files and API responses,
computing climatology statistics for the frontend application.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime


class WeatherCalculator:
    """Calculate climatology statistics from weather data."""
    
    def __init__(self, data_dir: str = "Backend/data"):
        """
        Initialize the calculator with data directory path.
        
        Args:
            data_dir: Path to directory containing Excel files
        """
        self.data_dir = Path(data_dir)
        self.data_cache = {}
    
    def load_data(self, location: str) -> pd.DataFrame:
        """
        Load weather data for a specific location from Excel files.
        
        Args:
            location: Location name (orlando, tampa, miami)
            
        Returns:
            DataFrame with weather data
        """
        location = location.lower()
        
        # Map location to file
        file_mapping = {
            'orlando': 'orlando_aprils.xlsx',
            'tampa': 'tampa.xlsx',
            'miami': 'miami_celsius.xlsx'
        }
        
        if location not in file_mapping:
            raise ValueError(f"Unknown location: {location}")
        
        # Check cache
        if location in self.data_cache:
            return self.data_cache[location]
        
        # Load from file
        file_path = self.data_dir / file_mapping[location]
        df = pd.read_excel(file_path)
        
        # Cache the data
        self.data_cache[location] = df
        
        return df
    
    def calculate_probability(self, data: pd.Series, threshold: float, 
                            operator: str = '>=') -> Dict:
        """
        Calculate probability with Wilson confidence interval.
        
        Args:
            data: Series of values
            threshold: Threshold value
            operator: Comparison operator ('>=', '<=', '>', '<')
            
        Returns:
            Dict with probability and confidence interval
        """
        # Remove NaN values
        clean_data = data.dropna()
        n = len(clean_data)
        
        if n == 0:
            return {'probability': 0, 'ci_lower': 0, 'ci_upper': 0, 'count': 0}
        
        # Count occurrences
        if operator == '>=':
            count = (clean_data >= threshold).sum()
        elif operator == '<=':
            count = (clean_data <= threshold).sum()
        elif operator == '>':
            count = (clean_data > threshold).sum()
        elif operator == '<':
            count = (clean_data < threshold).sum()
        else:
            raise ValueError(f"Unknown operator: {operator}")
        
        # Calculate probability
        p = count / n
        
        # Wilson score interval (95% confidence)
        z = 1.96  # 95% confidence
        denominator = 1 + z**2/n
        centre_adjusted_probability = p + z*z / (2*n)
        adjusted_standard_deviation = np.sqrt((p*(1 - p) + z*z / (4*n)) / n)
        
        lower_bound = (centre_adjusted_probability - z*adjusted_standard_deviation) / denominator
        upper_bound = (centre_adjusted_probability + z*adjusted_standard_deviation) / denominator
        
        return {
            'probability': round(p * 100, 1),
            'ci_lower': round(max(0, lower_bound * 100), 1),
            'ci_upper': round(min(100, upper_bound * 100), 1),
            'count': int(count),
            'total': int(n)
        }
    
    def calculate_percentile(self, data: pd.Series, percentile: int) -> float:
        """
        Calculate percentile value.
        
        Args:
            data: Series of values
            percentile: Percentile (0-100)
            
        Returns:
            Percentile value
        """
        clean_data = data.dropna()
        return clean_data.quantile(percentile / 100)
    
    def calculate_statistics(self, data: pd.Series) -> Dict:
        """
        Calculate basic statistics.
        
        Args:
            data: Series of values
            
        Returns:
            Dict with mean, std, min, max, etc.
        """
        clean_data = data.dropna()
        
        return {
            'mean': round(clean_data.mean(), 2),
            'std': round(clean_data.std(), 2),
            'min': round(clean_data.min(), 2),
            'max': round(clean_data.max(), 2),
            'median': round(clean_data.median(), 2),
            'count': len(clean_data),
            'p10': round(clean_data.quantile(0.10), 2),
            'p90': round(clean_data.quantile(0.90), 2),
            'p95': round(clean_data.quantile(0.95), 2)
        }
    
    def process_api_data(self, api_data: Dict) -> Dict:
        """
        Process data fetched from NASA APIs and calculate climatology statistics.
        
        Args:
            api_data: Dictionary containing temperature, wind, and precipitation DataFrames
                     from data_fetcher.fetch_historical_data()
            
        Returns:
            Dict with all climatology probabilities and statistics
        """
        results = {
            'location': api_data.get('location', 'Unknown'),
            'target_date': api_data.get('target_date', ''),
            'target_hour': api_data.get('target_hour', 12),
            'years_analyzed': api_data.get('years_fetched', 0),
            'saved_files': api_data.get('saved_files', [])
        }
        
        # Process Temperature Data
        temp_df = api_data.get('temperature', pd.DataFrame())
        if not temp_df.empty and 'Tair_f_inst' in temp_df.columns:
            temp_data = temp_df['Tair_f_inst']
            
            # Convert from Kelvin to Celsius if needed
            if temp_data.mean() > 100:  # Likely in Kelvin
                temp_data = temp_data - 273.15
            
            results['temperature'] = {
                'statistics': self.calculate_statistics(temp_data),
                'avg_temp': {
                    'value': round(temp_data.mean(), 1),
                    'std': round(temp_data.std(), 1)
                },
                'heat_wave': self._calculate_heat_wave(temp_data),
                'very_cold': self._calculate_cold(temp_data)
            }
        
        # Process Wind Data
        wind_df = api_data.get('wind', pd.DataFrame())
        if not wind_df.empty and 'SPEED' in wind_df.columns:
            wind_data = wind_df['SPEED']
            
            results['wind'] = {
                'statistics': self.calculate_statistics(wind_data),
                'very_windy': self._calculate_windy(wind_data)
            }
        
        # Process Precipitation Data
        precip_df = api_data.get('precipitation', pd.DataFrame())
        if not precip_df.empty and 'precipitationCal' in precip_df.columns:
            precip_data = precip_df['precipitationCal']
            
            results['precipitation'] = {
                'statistics': self.calculate_statistics(precip_data),
                'rain': self._calculate_rain(precip_data),
                'heavy_rain': self._calculate_heavy_rain(precip_data)
            }
        
        return results
    
    def _calculate_rain(self, precip_data: pd.Series) -> Dict:
        """Calculate rain probability (>=1mm)."""
        prob = self.calculate_probability(precip_data, 1.0, '>=')
        return {
            'probability': prob['probability'],
            'wilson_ci': [prob['ci_lower'], prob['ci_upper']],
            'definition': '≥1mm precipitation',
            'drivers': {
                'Historical days': prob['count'],
                'Total years': prob['total']
            }
        }
    
    def _calculate_heavy_rain(self, precip_data: pd.Series) -> Dict:
        """Calculate heavy rain probability (>=P95 or >=20mm)."""
        p95 = self.calculate_percentile(precip_data, 95)
        threshold = max(20.0, p95)
        prob = self.calculate_probability(precip_data, threshold, '>=')
        
        return {
            'probability': prob['probability'],
            'wilson_ci': [prob['ci_lower'], prob['ci_upper']],
            'definition': f'≥P95 ({p95:.1f}mm) or ≥20mm/day',
            'drivers': {
                'P95 threshold': round(p95, 1),
                'Max observed': round(precip_data.max(), 1)
            }
        }
    
    def _calculate_heat_wave(self, temp_data: pd.Series) -> Dict:
        """Calculate heat wave probability (>=P90)."""
        p90 = self.calculate_percentile(temp_data, 90)
        prob = self.calculate_probability(temp_data, p90, '>=')
        
        return {
            'probability': prob['probability'],
            'wilson_ci': [prob['ci_lower'], prob['ci_upper']],
            'definition': f'Temperature ≥P90 ({p90:.1f}°C)',
            'percentile': 90,
            'drivers': {
                'P90 threshold': round(p90, 1),
                'Max observed': round(temp_data.max(), 1)
            }
        }
    
    def _calculate_cold(self, temp_data: pd.Series) -> Dict:
        """Calculate very cold probability (<=P10)."""
        p10 = self.calculate_percentile(temp_data, 10)
        prob = self.calculate_probability(temp_data, p10, '<=')
        
        return {
            'probability': prob['probability'],
            'wilson_ci': [prob['ci_lower'], prob['ci_upper']],
            'definition': f'Temperature ≤P10 ({p10:.1f}°C)',
            'percentile': 10,
            'drivers': {
                'P10 threshold': round(p10, 1),
                'Min observed': round(temp_data.min(), 1)
            }
        }
    
    def _calculate_windy(self, wind_data: pd.Series) -> Dict:
        """Calculate very windy probability (>=10 m/s)."""
        threshold = 10.0  # 10 m/s
        prob = self.calculate_probability(wind_data, threshold, '>=')
        p90 = self.calculate_percentile(wind_data, 90)
        
        return {
            'probability': prob['probability'],
            'wilson_ci': [prob['ci_lower'], prob['ci_upper']],
            'definition': '≥10 m/s wind speed',
            'drivers': {
                'P90 wind': round(p90, 1),
                'Mean': round(wind_data.mean(), 1)
            }
        }
    
    def calculate_rain_probability(self, location: str, month: int, 
                                   day: int, window: int = 15) -> Dict:
        """
        Calculate rain probability for a specific date window.
        (Legacy method for Excel file processing)
        
        Args:
            location: Location name
            month: Month (1-12)
            day: Day of month
            window: +/- days window
            
        Returns:
            Dict with rain statistics
        """
        df = self.load_data(location)
        
        # Filter data by date window (implementation depends on data structure)
        # This is a template - adjust based on actual Excel structure
        
        # Example: assuming column 'precipitation' exists
        if 'precipitation' in df.columns:
            precip_data = df['precipitation']
            
            # Calculate probability of rain (>=1mm)
            rain_prob = self.calculate_probability(precip_data, 1.0, '>=')
            
            # Calculate probability of heavy rain (>=20mm or P95)
            p95 = self.calculate_percentile(precip_data, 95)
            heavy_threshold = max(20.0, p95)
            heavy_rain_prob = self.calculate_probability(precip_data, heavy_threshold, '>=')
            
            return {
                'rain': rain_prob,
                'heavy_rain': heavy_rain_prob,
                'statistics': self.calculate_statistics(precip_data),
                'p95_threshold': round(p95, 2)
            }
        
        return {}
    
    def calculate_temperature_metrics(self, location: str, month: int,
                                      day: int, window: int = 15) -> Dict:
        """
        Calculate temperature-related metrics.
        (Legacy method for Excel file processing)
        
        Args:
            location: Location name
            month: Month (1-12)
            day: Day of month
            window: +/- days window
            
        Returns:
            Dict with temperature statistics
        """
        df = self.load_data(location)
        
        # Example: assuming columns 'temp_max' and 'temp_min' exist
        results = {}
        
        if 'temp_max' in df.columns:
            temp_max = df['temp_max']
            
            # Average temperature
            results['avg_temp'] = self.calculate_statistics(temp_max)
            
            # Heat wave (P90 threshold)
            p90 = self.calculate_percentile(temp_max, 90)
            results['heat_wave'] = self.calculate_probability(temp_max, p90, '>=')
            results['p90_threshold'] = round(p90, 2)
        
        if 'temp_min' in df.columns:
            temp_min = df['temp_min']
            
            # Very cold (P10 threshold)
            p10 = self.calculate_percentile(temp_min, 10)
            results['very_cold'] = self.calculate_probability(temp_min, p10, '<=')
            results['p10_threshold'] = round(p10, 2)
        
        return results


# Example usage
if __name__ == "__main__":
    calculator = WeatherCalculator()
    
    # Example: Load Orlando data from Excel
    try:
        orlando_data = calculator.load_data('orlando')
        print(f"Orlando data loaded: {orlando_data.shape[0]} rows, {orlando_data.shape[1]} columns")
        print(f"\nColumns: {list(orlando_data.columns)}")
        print(f"\nFirst few rows:")
        print(orlando_data.head())
        
        # Example statistics
        if len(orlando_data.columns) > 0:
            first_col = orlando_data.columns[0]
            stats = calculator.calculate_statistics(orlando_data[first_col])
            print(f"\nStatistics for '{first_col}':")
            print(stats)
    
    except Exception as e:
        print(f"Error: {e}")
    
    # Example: Process API data
    print("\n\n--- Example API Data Processing ---")
    # Simulate API data structure
    sample_api_data = {
        'location': 'Tampa',
        'target_date': '06-15',
        'target_hour': 12,
        'years_fetched': 3,
        'temperature': pd.DataFrame({
            'Tair_f_inst': [298.15, 299.15, 297.15, 300.15, 298.65],  # Kelvin
            'year': [2020, 2021, 2022, 2023, 2024]
        }),
        'wind': pd.DataFrame({
            'SPEED': [5.2, 8.1, 12.3, 6.5, 9.8],
            'year': [2020, 2021, 2022, 2023, 2024]
        }),
        'precipitation': pd.DataFrame({
            'precipitationCal': [0.5, 15.2, 2.1, 0.0, 25.3],
            'year': [2020, 2021, 2022, 2023, 2024]
        }),
        'saved_files': ['file1.csv', 'file2.csv']
    }
    
    results = calculator.process_api_data(sample_api_data)
    print(f"\nProcessed data for {results['location']} on {results['target_date']} at hour {results['target_hour']}")
    print(f"Years analyzed: {results['years_analyzed']}")
    if 'temperature' in results:
        print(f"\nAverage Temperature: {results['temperature']['avg_temp']['value']}°C")
        print(f"Heat Wave Probability: {results['temperature']['heat_wave']['probability']}%")
    if 'precipitation' in results:
        print(f"\nRain Probability: {results['precipitation']['rain']['probability']}%")
