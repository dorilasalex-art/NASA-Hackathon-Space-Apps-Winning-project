# Weather Data Files

This directory contains Excel files with historical weather data for climatology calculations.

## Files

- `orlando_aprils.xlsx` - Orlando weather data for April months
- `tampa.xlsx` - Tampa weather data
- `miami_celsius.xlsx` - Miami weather data (temperatures in Celsius)

## Usage

These files are processed by Python scripts in `Backend/python/` to calculate:
- Rain probabilities
- Temperature statistics
- Heat wave and cold snap probabilities
- Wind and other climatology metrics

## Data Processing

See `Backend/python/weather_calculations.py` for the calculation logic.
