# NASA Climatology Planner

## Team Collaboration
**📖 See [TEAM_GUIDE.md](TEAM_GUIDE.md) for detailed Frontend/Backend file organization and development workflow.**

For VS Code users: Open `project.code-workspace` to see folders organized by Frontend/Backend sections.

## Overview
A production-ready climatology-based planning tool that analyzes long-range weather probabilities using 10 years of NASA Earth observation data. This is NOT a forecast tool - it provides historical climatology probabilities to help planners make informed decisions for future events.

## Current State (Live API Integration with Fallback)
The application now uses **Open-Meteo Historical Weather API** for real climatology data with automatic Excel fallback:

### Frontend Features
- SpaceX/Tesla-inspired dark UI (true black background, cyan accents)
- Simple location dropdown (Tampa, Orlando, Miami only)
- Month/day/hour selection with **Search button** (no automatic API calls)
- Climatology condition cards (Rain, Heavy Rain, Avg Temp, Very Windy, etc.)
- Dataset information display with disclaimers
- Historical trend panels
- Planner tips and recommendations with conditional logic
- Map visualization panel with smooth flyTo animations
- Export functionality placeholders

### Data Integration ✅
- **Primary Source - Open-Meteo API**: 
  - Fetches 10 years of historical weather data from Open-Meteo Historical Weather API
  - Completely free, no API key required
  - Works for **ANY month/day/year** (not limited to April)
  - Provides ~30 data points per query (3 years × 3-day window × hourly data)
  - Temperature, precipitation, and wind speed data
  - Implemented in `Backend/python/api_data_processor.py`
  
- **Fallback - Excel Data Files**: 
  - Automatically used if API is unavailable
  - `ORLANDO_all_aprils.xlsx`, `TAMPA_1.xlsx`, `MIAMI_1_celsius.xlsx`
  - April data only (2000-2019)
  - Implemented in `Backend/python/excel_data_processor.py`

- **Smart Routing**: Backend tries API first, falls back to Excel on failure
- **User Flow**: User selects location/date/time → Clicks "Search" → Gets real API data
- **Data Source Tracking**: Response includes `dataSource` field (API or Excel)

## Project Architecture

### Frontend (Complete)
- **Stack**: React + TypeScript + Tailwind CSS + Wouter
- **Components**: Fully functional interactive components with mock data
- **Design**: Dark theme with true black (#000000) background, primary color cyan (#30C1FF)
- **State Management**: React hooks (will need React Query for API integration)

### Backend (Needs Implementation)
**Current**: Node.js + Express with mock endpoints
**Required**: Python FastAPI with xarray + dask for NASA data processing

#### Backend Architecture Requirements (from v2 spec):
1. **Framework**: Python FastAPI
2. **Data Processing**: 
   - xarray for NetCDF/HDF5 handling
   - dask for parallel processing
   - pandas for climatology statistics
3. **Caching**: 
   - Redis for query results
   - Zarr for pre-tiled data
   - ETag/If-Modified-Since support
4. **Performance SLA**:
   - ≤15s uncached queries
   - ≤3s cached queries

#### API Endpoints (Implemented as mocks, need real data):
- `POST /api/probabilities` - Compute climatology probabilities with Wilson CI
- `GET /api/history` - Fetch historical observations
- `GET /api/trends` - Compute trend analysis

### Data Sources
1. **Precipitation**: GPM IMERG (NASA GES DISC)
2. **Temperature/Wind/Humidity/Cloud**: MERRA-2 (NASA GMAO)
3. **Snow**: MERRA-2, GLDAS, or NOAA datasets
4. **Cloud (alternative)**: MODIS/VIIRS

### Data Processing Method
- ±k-day climatology windows across 10 years (configurable)
- Wilson 95% confidence intervals for probabilities
- Bootstrap methods for small samples
- Percentile-based thresholds (P90 for hot, P10 for cold, P95 for heavy rain)

## Recent Changes

### Month-Specific Climatology (Latest)
- **Orlando now has month-specific data**: Different climatology values for April and June
  - April: rain=48.7%, temp=16.4°C, wind=2.9%
  - June: rain=68.0%, temp=28.9°C, wind=38.0%
- **Automatic fallback**: Months without specific data (Jan, Feb, Mar, May, Jul, Aug, Sep, Oct, Nov, Dec) automatically fall back to general climatology
- **Immediate updates**: Month selector triggers instant data refresh without requiring an "Apply" button
- **Robust null handling**: All components gracefully handle missing/null metrics with "--" placeholder display
- **Data architecture**: `getClimatologyForMonth()` helper retrieves month-specific data when available, falls back to general climatology otherwise

### v1 → v2 Alignment

#### Reframed from Forecast to Climatology
- Changed from real-time forecast probabilities to historical climatology
- Added "Climatology, not forecast" disclaimers
- Display dataset versions and temporal coverage

#### Updated Conditions
**Old (v1)**: Very Hot, Very Cold, Very Windy, Very Wet, Very Uncomfortable
**New (v2)**: Rain, Heavy Rain, Avg Temp, Heat Wave, Very Cold, Very Windy, Cloud Cover, Snow, Uncomfortable

### New Probability Definitions
- Rain: ≥1mm precipitation
- Heavy Rain: ≥P95 or ≥20mm/day
- Avg Temp: Mean daily temperature
- Heat Wave: ≥2 consecutive P90 days
- Very Cold: P10 Tmin
- Very Windy: Wind ≥10 m/s
- Cloud Cover: ≥70% coverage
- Snow: Historical occurrence
- Uncomfortable: HI ≥32°C OR WC ≤-10°C

### Added Features
1. **Historical Panels**: Show 10 years of trend data
2. **Planner Tips**: Context-aware recommendations (umbrella, backup venue, etc.)
3. **Dataset Metadata**: Display versions, resolution, coverage
4. **Trend Indicators**: Increasing/decreasing/stable badges
5. **Wilson CI**: 95% confidence intervals for all probabilities
6. **Time Selection**: Users can specify target hour for more precise climatology analysis
7. **Raw Data Archival**: All NASA API responses automatically saved as CSV files for verification

## Next Steps

### Phase 1: Backend Implementation
1. Set up Python FastAPI server alongside Node.js (or replace)
2. Implement xarray-based NetCDF data access to NASA GES DISC OPeNDAP
3. Create dataset registry with MERRA-2, GPM IMERG, GLDAS entries
4. Implement climatology computation with Wilson CI
5. Add Redis caching layer
6. Implement trend analysis algorithms

### Phase 2: API Integration
1. Replace mock data with real API calls
2. Add loading states and error handling
3. Implement query parameter passing from UI
4. Add result caching on frontend

### Phase 3: Performance & Testing
1. Optimize for ≤15s uncached, ≤3s cached SLA
2. Add Playwright E2E tests
3. Implement observability (timing metrics, cache hit ratio)
4. Load testing and optimization

### Phase 4: Export & Sharing
1. Implement PDF/PNG export with html2canvas
2. Add JSON data export
3. Create shareable URLs with query parameters
4. Implement copy-to-clipboard functionality

## User Preferences
- Keep SpaceX/Tesla dark design aesthetic
- Prioritize climatology accuracy over forecast-like predictions
- Show all data sources and disclaimers transparently
- Focus on planner use cases (events, construction, travel planning)
