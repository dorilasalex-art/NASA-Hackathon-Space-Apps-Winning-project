# NASA Condition Likelihoods - Design Guidelines

## Design Approach: SpaceX/Tesla Dark UI Reference

**Selected Approach**: Reference-Based (SpaceX/Tesla aesthetic)  
**Justification**: Scientific/data-heavy application requiring high contrast, precision, and professional credibility. The space/aerospace design language establishes trust and technical authority for NASA data visualization.

## Core Design Principles

1. **Maximum Contrast**: True black background with crisp white text for optimal data readability
2. **Precision First**: Clean, technical interface prioritizing information density and accuracy
3. **Minimal Distraction**: Subtle UI elements that don't compete with critical data displays
4. **Professional Authority**: Aerospace-inspired aesthetic reinforcing NASA data credibility

## Color Palette

**Dark Mode (Primary)**
- Background: True Black `#000000` (0 0% 0%)
- Primary Text: Pure White `#FFFFFF` (0 0% 100%)
- Grid Lines/Borders: Subtle Gray `#1a1a1a` to `#2a2a2a` (0 0% 10% to 16%)
- Interactive Accent: Cyan Blue `#30C1FF` (195 100% 59%)
- Focus Ring: `#30C1FF` with reduced opacity for consistent interaction states
- Success/Positive: Muted Green `#10b981` (160 84% 39%)
- Warning: Amber `#f59e0b` (38 92% 50%)
- Error: Red `#ef4444` (0 84% 60%)

**Data Visualization Colors**
- Heat/Temperature: Red-Orange gradient
- Cold: Blue-Cyan gradient
- Wind: Teal-Green gradient
- Precipitation: Blue spectrum
- Discomfort: Purple-Red gradient

## Typography

**Font Stack**: System fonts for performance
- Primary: `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`
- Monospace (data display): `'Monaco', 'Menlo', monospace`

**Type Scale**
- Header: `text-2xl font-bold` (24px) - Application title
- Timestamp: `text-sm text-gray-400` (14px) - Subtle metadata
- Card Titles: `text-lg font-semibold` (18px) - Condition names
- Probability Numbers: `text-5xl font-bold` (48px) - Primary data points
- Body Text: `text-base` (16px) - Rationale and descriptions
- Labels: `text-sm font-medium` (14px) - Form inputs and legends

## Layout System

**Spacing Primitives**: Tailwind units of `2, 4, 6, 8, 12, 16`
- Component padding: `p-4` to `p-6`
- Section spacing: `gap-8` to `gap-12`
- Card margins: `m-4`
- Grid gaps: `gap-6`

**Breakpoints**
- Mobile: Base (< 768px)
- Tablet: `md:` (768px+)
- Desktop: `lg:` (1024px+)
- Wide: `xl:` (1280px+)

**Grid Structure**
- Location/Time Panel: Single column on mobile, `md:grid-cols-2` on tablet+
- Indicators Grid: `grid-cols-1 md:grid-cols-2 lg:grid-cols-5` - 5 condition cards
- Map Panel: Full-width with `lg:h-96` minimum height

## Component Library

### Header Component
- Fixed/sticky navigation with backdrop blur
- Application title (left-aligned)
- Last-updated timestamp (right-aligned)
- Max-width container: `max-w-7xl mx-auto`

### Location/Time Panel
- Search input with geocoding autocomplete
- Manual lat/lon inputs (side-by-side on desktop)
- Date/time range picker with calendar popup
- Resolution dropdown (hourly/3-hourly/daily)
- "Now + Next 72h" quick action button
- Dark input styling: `bg-gray-900 border-gray-700 focus:border-cyan-500`

### Likelihood Cards (×5)
- Dark card background: `bg-gray-900`
- Subtle border: `border border-gray-800`
- Large probability percentage (center-aligned, `text-5xl`)
- Qualitative label (Low/Slight/Moderate/High/Very High)
- Confidence interval bar (90% CI visualization)
- Key drivers text (Tmax, RH, wind speed, etc.)
- Mini sparkline chart (D3.js, 60px height)
- Hover state: Subtle border glow `hover:border-cyan-500/50`

### Map Panel Component
- MapLibre GL JS dark basemap (dark-matter style)
- Location marker with cyan accent color
- Layer toggle buttons (wind/precip/temperature overlays)
- Legend with gradient colorbar
- Zoom/pan controls (bottom-right)
- Attribution footer (subtle gray text)

### Export/Share Section
- Primary button: PDF/PNG export with download icon
- Secondary button: Copy shareable URL with link icon
- JSON data download option
- Button styling: `bg-cyan-600 hover:bg-cyan-700` for primary actions

## Interactive Elements

**Buttons**
- Primary: `bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3 rounded-lg`
- Secondary: `bg-gray-800 hover:bg-gray-700 text-white px-6 py-3 rounded-lg`
- Ghost: `text-cyan-500 hover:bg-cyan-500/10 px-4 py-2 rounded`

**Form Inputs**
- Background: `bg-gray-900`
- Border: `border-gray-700`
- Focus: `focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20`
- Rounded corners: `rounded-lg`

**Focus States**
- Consistent cyan ring: `focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-black`
- High contrast for accessibility

## Accessibility Features

- WCAG AA minimum contrast ratios (true black background ensures high contrast)
- Keyboard navigation with visible focus indicators
- ARIA labels for all interactive elements
- Screen reader announcements for probability updates
- Color-blind safe data visualization palettes
- Skip-to-content links
- Semantic HTML structure

## Data Visualization Standards

**Sparkline Charts**
- Height: 60px
- Stroke: `#30C1FF` (2px width)
- Background grid: Subtle gray dotted lines
- No axis labels (minimalist)
- Tooltip on hover with precise values

**Map Overlays**
- Smooth color gradients for continuous data
- Transparent overlays (60-80% opacity)
- Legend positioned top-right with clear units
- Colorbar with 5-7 discrete steps

## Loading & Error States

**Loading Indicators**
- Skeleton screens matching component structure
- Subtle pulse animation: `animate-pulse`
- Cyan spinner for async operations

**Error Banners**
- Dark red background: `bg-red-900/20 border border-red-800`
- Error icon (alert triangle)
- Clear error message with retry action
- Dismissible with close button

## Performance Optimization

- Lazy loading for map tiles
- Virtual scrolling for large datasets (if needed)
- Debounced search inputs (300ms)
- Memoized chart components
- Code splitting for map library
- Preload critical fonts and icons

## Responsive Behavior

**Mobile (<768px)**
- Stacked single-column layout
- Collapsible panels for space efficiency
- Touch-optimized button sizes (min 44px)
- Swipeable likelihood cards

**Tablet (768px-1024px)**
- 2-column grid for condition cards
- Side-by-side location/time inputs
- Partial map visibility

**Desktop (1024px+)**
- 5-column condition cards (all visible)
- Split-screen: controls left, map right
- Full data dashboard experience