# NASA Climatology Planner

A production-ready climatology-based planning tool that analyzes long-range weather probabilities using 30+ years of NASA Earth observation data.

## 🚀 Quick Start

```bash
npm install
npm run dev
```

The app will be available at `http://localhost:5000`

## 👥 Team Development

**Working with the team?** See **[TEAM_GUIDE.md](TEAM_GUIDE.md)** for detailed Frontend/Backend organization.

### Quick Navigation

- **Frontend Team**: Work in `client/` directory
  - React components, pages, and UI
  - See `client/src/` for all frontend code
  
- **Backend Team**: Work in `server/` directory  
  - Express API, routes, and storage
  - See `server/routes.ts` for API endpoints

- **Shared Code**: `shared/schema.ts`
  - Data models and type definitions used by both teams

### VS Code Users

Open the workspace file for organized folder view:
```bash
code project.code-workspace
```

This groups folders by Frontend/Backend for easier navigation.

## 📚 Documentation

- [TEAM_GUIDE.md](TEAM_GUIDE.md) - Complete team collaboration guide
- [replit.md](replit.md) - Project overview and architecture
- [design_guidelines.md](design_guidelines.md) - Design system documentation

## 🛠 Tech Stack

**Frontend:**
- React 18 + TypeScript
- Tailwind CSS + shadcn/ui
- Wouter (routing)
- TanStack Query
- MapLibre GL JS

**Backend:**
- Node.js + Express
- TypeScript
- Drizzle ORM (planned)
- PostgreSQL (planned)

## 📋 Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run check` - Type checking
- `npm run db:push` - Push database schema changes

## 🗂 Project Structure

```
├── client/           # 🎨 FRONTEND - All React/UI code
│   ├── src/
│   │   ├── components/  # React components
│   │   ├── pages/       # Page components
│   │   ├── lib/         # Utilities
│   │   └── hooks/       # Custom hooks
│   └── index.html
│
├── server/           # ⚙️ BACKEND - All API/server code
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API routes
│   └── storage.ts       # Data storage
│
├── shared/           # 🔗 SHARED - Types & schemas
│   └── schema.ts
│
└── [config files]    # Build & tooling configuration
```

## 🎯 Key Features

- SpaceX/Tesla-inspired dark UI
- Interactive location selection with map
- 9 climatology condition cards
- Month-specific climatology data
- Historical trend analysis
- Export functionality
- Real-time data updates

## 📖 Learn More

For detailed information about the project architecture, data sources, and development guidelines, see [replit.md](replit.md).

---

**Note:** This is a climatology tool, not a forecast tool. It provides historical climate probabilities based on 30+ years of NASA data.
