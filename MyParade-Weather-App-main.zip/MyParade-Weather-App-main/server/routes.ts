import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { climatologyQuerySchema } from "@shared/schema";
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

export async function registerRoutes(app: Express): Promise<Server> {
  // Fetch real-time weather data from NASA APIs and calculate statistics
  // POST /api/fetch-weather
  app.post("/api/fetch-weather", async (req, res) => {
    try {
      const query = climatologyQuerySchema.parse(req.body);
      
      // Map location name from coordinates (simplified - you may want to enhance this)
      let locationName = query.location || "Tampa";
      
      // If coordinates are provided, determine which city is closest
      if (query.lat && query.lon) {
        // Simple distance calculation to find closest city
        const cities = [
          { name: "Orlando", lat: 28.55, lon: -81.20 },
          { name: "Tampa", lat: 28.06, lon: -82.41 },
          { name: "Miami", lat: 25.76, lon: -80.38 }
        ];
        
        let minDist = Infinity;
        cities.forEach(city => {
          const dist = Math.sqrt(
            Math.pow(city.lat - query.lat, 2) + 
            Math.pow(city.lon - query.lon, 2)
          );
          if (dist < minDist) {
            minDist = dist;
            locationName = city.name;
          }
        });
      }
      
      const day = query.targetDay || 15;
      const hour = query.targetHour || 12;
      
      // Try API first, fallback to Excel if it fails
      let pythonResults;
      let dataSource = 'API';
      
      try {
        // Try Open-Meteo API first
        const apiArgs = [
          'Backend/python/api_data_processor.py',
          '--location', locationName,
          '--month', String(query.targetMonth),
          '--day', String(day),
          '--hour', String(hour)
        ];
        
        console.log(`Trying API: python3 ${apiArgs.join(' ')}`);
        const { stdout: apiStdout, stderr: apiStderr } = await execFileAsync('python3', apiArgs);
        
        if (apiStderr) {
          console.log('API stderr:', apiStderr);
        }
        
        pythonResults = JSON.parse(apiStdout);
        
        // If API fails, fallback to Excel
        if (!pythonResults.success) {
          throw new Error('API data not available');
        }
        
        console.log(`✓ Successfully fetched data from Open-Meteo API`);
        
      } catch (apiError) {
        // Fallback to Excel files
        console.log(`API failed, falling back to Excel files: ${apiError instanceof Error ? apiError.message : String(apiError)}`);
        dataSource = 'Excel';
        
        try {
          const excelArgs = [
            'Backend/python/excel_data_processor.py',
            '--location', locationName,
            '--month', String(query.targetMonth),
            '--day', String(day),
            '--hour', String(hour)
          ];
          
          console.log(`Executing Excel fallback: python3 ${excelArgs.join(' ')}`);
          const { stdout, stderr } = await execFileAsync('python3', excelArgs);
          
          if (stderr) {
            console.log('Excel stderr:', stderr);
          }
          
          pythonResults = JSON.parse(stdout);
          
          if (!pythonResults.success) {
            throw new Error('Excel data not available');
          }
          
          console.log(`✓ Successfully fetched data from Excel files`);
          
        } catch (excelError) {
          // Final fallback: Generate reasonable placeholder data
          console.log(`Excel failed, using placeholder data: ${excelError instanceof Error ? excelError.message : String(excelError)}`);
          dataSource = 'Placeholder';
          
          // Generate climatology-appropriate placeholder values based on location and season
          const monthSeasons: { [key: number]: string } = {
            12: 'winter', 1: 'winter', 2: 'winter',
            3: 'spring', 4: 'spring', 5: 'spring',
            6: 'summer', 7: 'summer', 8: 'summer',
            9: 'fall', 10: 'fall', 11: 'fall'
          };
          const season = monthSeasons[query.targetMonth];
          
          // Florida climate baseline values
          const baselineTemp = season === 'summer' ? 28 : season === 'winter' ? 18 : 23;
          const baselineRain = season === 'summer' ? 45 : season === 'winter' ? 15 : 30;
          const baselineWind = 3;
          
          pythonResults = {
            success: true,
            location: locationName,
            target_month: query.targetMonth,
            target_day: day,
            target_hour: hour,
            data_points: 10, // Indicate limited confidence
            statistics: {
              temperature: {
                mean: baselineTemp,
                std: 3,
                count: 10
              },
              wind: {
                mean: baselineWind,
                p90: baselineWind * 2,
                very_windy_prob: 5,
                count: 10
              },
              precipitation: {
                mean: 1,
                rain_prob: baselineRain,
                heavy_rain_prob: 5,
                count: 10
              }
            }
          };
          
          console.log(`⚠️ Using placeholder climatology data (estimated values)`);
        }
      }
      
      // Transform Excel statistics into frontend format
      const stats = pythonResults.statistics;
      
      const response = {
        inputs: query,
        location: pythonResults.location,
        targetDate: `${query.targetMonth}/${day}`,
        targetHour: pythonResults.target_hour,
        dataPoints: pythonResults.data_points,
        dataSource: dataSource,
        climatology: {
          rain: {
            probability: stats.precipitation.rain_prob,
            definition: "≥1mm precipitation",
            wilsonCI: { lower: null, upper: null },
            drivers: []
          },
          heavyRain: {
            probability: stats.precipitation.heavy_rain_prob,
            definition: "≥20mm precipitation",
            wilsonCI: { lower: null, upper: null },
            drivers: []
          },
          avgTemp: {
            probability: null,
            avgValue: stats.temperature.mean,
            definition: `Mean temperature`,
            wilsonCI: { lower: null, upper: null },
            drivers: []
          },
          veryWindy: {
            probability: stats.wind.very_windy_prob,
            definition: "Wind speed ≥10 m/s",
            wilsonCI: { lower: null, upper: null },
            drivers: []
          },
          heatWave: null,
          veryCold: null,
          cloudCover: null,
          snow: null,
          uncomfortable: null
        },
        historicalData: [],
        computedAt: new Date().toISOString(),
        cacheHit: false
      };
      
      res.json(response);
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid query parameters", details: error.errors });
      }
      console.error("Error fetching weather data:", error);
      res.status(500).json({ 
        error: "Failed to fetch weather data", 
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Climatology probabilities endpoint (legacy/mock data)
  // POST /api/probabilities
  app.post("/api/probabilities", async (req, res) => {
    try {
      const query = climatologyQuerySchema.parse(req.body);
      
      // TODO: Replace with actual Python FastAPI backend call or implement xarray/netCDF processing
      // For now, return mock climatology data
      const response = {
        inputs: query,
        probabilities: {
          rain: {
            probability: 65,
            wilsonCI: [58, 72] as [number, number],
            definition: "≥1mm precipitation",
            drivers: { "Historical days": 19, "Total years": 30 },
            trend: "stable" as const
          },
          heavyRain: {
            probability: 15,
            wilsonCI: [10, 22] as [number, number],
            definition: "≥P95 or ≥20mm/day",
            drivers: { "P95 threshold": 22.5, "Max observed": 45.2 },
            trend: "increasing" as const
          },
          avgTemp: {
            probability: 28.5,
            wilsonCI: [27.2, 29.8] as [number, number],
            definition: "Mean daily temperature",
            avgValue: 28.5,
            drivers: { "Historical mean": 28.5, "Std dev": 2.1 },
            trend: "increasing" as const
          },
          heatWave: {
            probability: 22,
            wilsonCI: [16, 29] as [number, number],
            definition: "≥2 consecutive P90 days",
            percentile: 90,
            drivers: { "P90 Tmax": 35.2, "Consecutive": 2 },
            trend: "increasing" as const
          },
          veryCold: {
            probability: 8,
            wilsonCI: [4, 14] as [number, number],
            definition: "P10 Tmin ≤5°C",
            percentile: 10,
            drivers: { "P10 Tmin": 5.2, "Historical": 2 },
            trend: "decreasing" as const
          },
          veryWindy: {
            probability: 35,
            wilsonCI: [28, 42] as [number, number],
            definition: "Wind ≥10 m/s",
            drivers: { "P90 wind": 12.5, "Mean": 7.8 },
            trend: "stable" as const
          },
          cloudCover: {
            probability: 70,
            wilsonCI: [63, 77] as [number, number],
            definition: "Cloud cover ≥70%",
            drivers: { "Mean cover": 72, "Clear days": 9 },
            trend: "stable" as const
          },
          snow: {
            probability: 2,
            wilsonCI: [0, 6] as [number, number],
            definition: "Snow occurrence",
            drivers: { "Historical events": 1, "Years": 30 },
            trend: "decreasing" as const
          },
          uncomfortable: {
            probability: 45,
            wilsonCI: [38, 52] as [number, number],
            definition: "HI ≥32°C or WC ≤-10°C",
            drivers: { "Heat Index": 34.2, "RH": 78 },
            trend: "increasing" as const
          }
        },
        history: Array.from({ length: 10 }, (_, i) => ({
          year: 2014 + i,
          values: {
            rain: 55 + Math.random() * 15,
            temp: 27 + Math.random() * 2.5
          }
        })),
        datasets: [
          {
            name: "GPM IMERG",
            version: "V07B",
            source: "NASA GES DISC",
            temporalResolution: "30-min",
            spatialResolution: "0.1° × 0.1°",
            coverage: "1998-present"
          },
          {
            name: "MERRA-2",
            version: "5.12.4",
            source: "NASA GMAO",
            temporalResolution: "1-hourly",
            spatialResolution: "0.5° × 0.625°",
            coverage: "1980-present"
          }
        ],
        computedAt: new Date().toISOString(),
        cacheHit: false
      };

      res.json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid query parameters", details: error.errors });
      }
      console.error("Error computing climatology:", error);
      res.status(500).json({ error: "Failed to compute climatology probabilities" });
    }
  });

  // Historical trends endpoint
  // GET /api/history?lat=...&lon=...&metric=...
  app.get("/api/history", async (req, res) => {
    try {
      const { lat, lon, metric } = req.query;
      
      // TODO: Implement actual historical data retrieval
      const history = Array.from({ length: 30 }, (_, i) => ({
        year: 1994 + i,
        values: {
          [metric as string]: 50 + Math.random() * 30
        }
      }));

      res.json({ history });
    } catch (error) {
      console.error("Error fetching history:", error);
      res.status(500).json({ error: "Failed to fetch historical data" });
    }
  });

  // Dataset trends endpoint
  // GET /api/trends?lat=...&lon=...
  app.get("/api/trends", async (req, res) => {
    try {
      const { lat, lon } = req.query;
      
      // TODO: Implement actual trend analysis
      const trends = {
        rain: "increasing",
        temp: "increasing",
        wind: "stable",
        cloud: "stable"
      };

      res.json({ trends });
    } catch (error) {
      console.error("Error computing trends:", error);
      res.status(500).json({ error: "Failed to compute trends" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
