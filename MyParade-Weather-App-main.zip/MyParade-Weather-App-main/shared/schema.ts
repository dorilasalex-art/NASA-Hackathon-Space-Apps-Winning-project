import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Climatology probability result schema
export const climatologyResultSchema = z.object({
  probability: z.number().min(0).max(100),
  wilsonCI: z.tuple([z.number(), z.number()]),
  definition: z.string(),
  drivers: z.record(z.number()),
  percentile: z.number().optional(),
  avgValue: z.number().optional(),
  trend: z.enum(["increasing", "decreasing", "stable"]).optional(),
});

// Dataset metadata schema
export const datasetMetaSchema = z.object({
  name: z.string(),
  version: z.string(),
  source: z.string(),
  temporalResolution: z.string(),
  spatialResolution: z.string(),
  coverage: z.string(),
});

// Climatology query input schema
export const climatologyQuerySchema = z.object({
  lat: z.number().min(-90).max(90),
  lon: z.number().min(-180).max(180),
  location: z.string().optional(),
  targetMonth: z.number().min(1).max(12),
  targetDay: z.number().min(1).max(31).optional(),
  targetHour: z.number().min(0).max(23).default(12),
  windowDays: z.number().min(1).max(30).default(7),
});

// Climatology response schema
export const climatologyResponseSchema = z.object({
  inputs: climatologyQuerySchema,
  probabilities: z.object({
    rain: climatologyResultSchema,
    heavyRain: climatologyResultSchema,
    avgTemp: climatologyResultSchema,
    heatWave: climatologyResultSchema,
    veryCold: climatologyResultSchema,
    veryWindy: climatologyResultSchema,
    cloudCover: climatologyResultSchema,
    snow: climatologyResultSchema,
    uncomfortable: climatologyResultSchema,
  }),
  history: z.array(z.object({
    year: z.number(),
    values: z.record(z.number()),
  })),
  datasets: z.array(datasetMetaSchema),
  computedAt: z.string(),
  cacheHit: z.boolean().optional(),
});

export type ClimatologyQuery = z.infer<typeof climatologyQuerySchema>;
export type ClimatologyResult = z.infer<typeof climatologyResultSchema>;
export type ClimatologyResponse = z.infer<typeof climatologyResponseSchema>;
export type DatasetMeta = z.infer<typeof datasetMetaSchema>;

// User schema (keep for auth if needed later)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
